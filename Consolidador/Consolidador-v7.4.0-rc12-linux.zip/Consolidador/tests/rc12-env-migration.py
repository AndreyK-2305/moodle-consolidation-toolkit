#!/usr/bin/env python3
"""Ejecuta la migración real de .env aislada, sin invocar Docker."""
from pathlib import Path
import os
import subprocess
import tempfile

launcher = (Path(__file__).resolve().parent.parent / 'moodle-consolidation.sh').read_text()
start = "    python3 - <<'PY'\n"
if launcher.count(start) != 1:
    raise SystemExit('RC12_ENV_FAILED: no se encontró la migración única')
program = launcher.split(start, 1)[1].split('\nPY\n', 1)[0]
old = 'moodle-consolidation-target:5.2.1-v7.4.0-rc' + '11'
new = 'moodle-consolidation-target:5.2.1-v7.4.0-rc12'
with tempfile.TemporaryDirectory(prefix='rc12-env-') as directory:
    path = Path(directory) / '.env'
    original = f'MOODLE_TARGET_IMAGE={old}\nOTHER_SETTING=preserve-me\n'.encode()
    path.write_bytes(original)
    path.chmod(0o600)
    # Un archivo de una tentativa anterior no debe impedir un reintento.
    (Path(directory) / '.env.rc12.partial').write_text('incompleto')
    subprocess.run(['python3', '-c', program], cwd=directory, check=True)
    changed = path.read_bytes()
    if changed != original.replace(old.encode(), new.encode()) or \
            path.stat().st_mode & 0o777 != 0o600:
        raise SystemExit('RC12_ENV_FAILED: alteró un ajuste ajeno o permisos')
    if not (Path(directory) / '.env.rc12.partial').exists():
        raise SystemExit('RC12_ENV_FAILED: alteró la tentativa ajena')
    # PREPARAR-DESTINO.sh evita repetir la migración cuando ya ve el tag RC12.
    if new not in changed.decode() or old in changed.decode():
        raise SystemExit('RC12_ENV_FAILED: etiqueta no quedó actualizada')
    if 'previous_runtime_rc=11' not in launcher or \
            'MOODLE_TARGET_IMAGE:-}' not in launcher:
        raise SystemExit('RC12_ENV_FAILED: no existe protección de reintentos')
    before = path.read_bytes()
    if new in path.read_text():
        pass
    else:
        subprocess.run(['python3', '-c', program], cwd=directory, check=True)
    if path.read_bytes() != before:
        raise SystemExit('RC12_ENV_FAILED: preparación repetida cambió .env')
print('RC12_ENV_OK rc11_migrated=1 other_settings=preserved retry=idempotent')
