<?php
// Contrato de usuarios contenidos en users.xml, independiente de matrículas.

declare(strict_types=1);

/** Lee solo users.xml del MBZ, sin extraer los archivos académicos ni alterarlos. */
function p6_backup_users_xml(string $backup): array {
    global $CFG;

    if (!is_readable($backup)) {
        throw new RuntimeException('No se puede leer el MBZ: ' . $backup);
    }
    $temporary = tempnam($CFG->tempdir, 'p6-users-');
    if ($temporary === false) {
        throw new RuntimeException('No se pudo reservar espacio para users.xml.');
    }
    try {
        $copied = false;
        $zip = new ZipArchive();
        if ($zip->open($backup) === true) {
            try {
                foreach (['users.xml', './users.xml'] as $member) {
                    $stream = $zip->getStream($member);
                    if ($stream === false) {
                        continue;
                    }
                    $destination = fopen($temporary, 'wb');
                    if ($destination === false) {
                        fclose($stream);
                        throw new RuntimeException('No se pudo escribir users.xml temporal.');
                    }
                    try {
                        $copied = stream_copy_to_stream($stream, $destination) !== false;
                    } finally {
                        fclose($stream);
                        fclose($destination);
                    }
                    break;
                }
            } finally {
                $zip->close();
            }
        } else {
            foreach (['users.xml', './users.xml'] as $member) {
                $process = proc_open(
                    ['tar', '-xOf', '--', $backup, $member],
                    [1 => ['pipe', 'w'], 2 => ['pipe', 'w']],
                    $pipes
                );
                if (!is_resource($process)) {
                    throw new RuntimeException('No se pudo inspeccionar el MBZ tar.');
                }
                $destination = fopen($temporary, 'wb');
                if ($destination === false) {
                    fclose($pipes[1]);
                    fclose($pipes[2]);
                    proc_close($process);
                    throw new RuntimeException('No se pudo escribir users.xml temporal.');
                }
                $bytes = stream_copy_to_stream($pipes[1], $destination);
                fclose($destination);
                fclose($pipes[1]);
                $stderr = stream_get_contents($pipes[2]);
                fclose($pipes[2]);
                $exit = proc_close($process);
                if ($exit === 0 && $bytes !== false) {
                    $copied = true;
                    break;
                }
                if ($exit !== 0 && $member === './users.xml') {
                    throw new RuntimeException(
                        'El MBZ no permite leer users.xml: ' . substr((string)$stderr, 0, 500)
                    );
                }
            }
        }
        if (!$copied || filesize($temporary) === 0) {
            throw new RuntimeException('El MBZ no contiene un users.xml legible.');
        }
        return p6_parse_backup_users_xml($temporary);
    } finally {
        unlink($temporary);
    }
}

/** DOM por usuario, evitando cargar el XML completo en memoria. */
function p6_parse_backup_users_xml(string $path): array {
    $reader = new XMLReader();
    if (!$reader->open($path, null, LIBXML_NONET)) {
        throw new RuntimeException('No se pudo abrir users.xml.');
    }
    $reader->setParserProperty(XMLReader::LOADDTD, false);
    $reader->setParserProperty(XMLReader::SUBST_ENTITIES, false);
    $rows = [];
    try {
        while ($reader->read()) {
            if ($reader->nodeType !== XMLReader::ELEMENT || $reader->name !== 'user') {
                continue;
            }
            $xml = $reader->readOuterXML();
            $dom = new DOMDocument();
            if ($xml === '' || !$dom->loadXML($xml, LIBXML_NONET) ||
                    !$dom->documentElement instanceof DOMElement) {
                throw new RuntimeException('users.xml contiene un usuario inválido.');
            }
            $user = $dom->documentElement;
            $id = (int)$user->getAttribute('id');
            if ($id < 1 || isset($rows[$id])) {
                throw new RuntimeException('users.xml tiene un ID inválido o repetido: ' . $id);
            }
            $deleted = trim(p5_dom_text($user, 'deleted'));
            if (!in_array($deleted, ['', '0', '1'], true)) {
                throw new RuntimeException('users.xml tiene deleted inválido para ID ' . $id);
            }
            $rows[$id] = [
                'source_user_id' => $id,
                'source_username' => p5_dom_text($user, 'username'),
                'source_email' => p5_dom_text($user, 'email'),
                'deleted' => $deleted === '1',
            ];
        }
    } finally {
        $reader->close();
    }
    ksort($rows, SORT_NUMERIC);
    return array_values($rows);
}

/** La clasificación es determinista y forma parte del job sellado. */
function p6_classify_backup_users(
    array $users,
    string $sourceid,
    array $academicids,
    array $globalmap
): array {
    $academic = array_fill_keys(array_map('intval', $academicids), true);
    $observedacademic = [];
    $historicalmapconflicts = [];
    $audit = [];
    $counts = array_fill_keys([
        'academic_mapped', 'auxiliary_mapped', 'historical_deleted',
        'reserved_guest', 'academic_reference_unmapped', 'active_unmapped',
    ], 0);
    foreach ($users as $user) {
        $id = (int)$user['source_user_id'];
        $isacademic = isset($academic[$id]);
        if ($isacademic) {
            $observedacademic[$id] = true;
        }
        $mapping = $globalmap[$sourceid . ':' . $id] ?? null;
        if (strtolower(trim((string)$user['source_username'])) === 'guest') {
            $status = 'reserved_guest';
        } elseif ($user['deleted'] === true) {
            $status = 'historical_deleted';
            if (is_array($mapping)) {
                $historicalmapconflicts[] = $id;
            }
        } elseif (is_array($mapping) && (int)($mapping['target_user_id'] ?? 0) > 0) {
            $status = $isacademic ? 'academic_mapped' : 'auxiliary_mapped';
        } elseif ($isacademic) {
            $status = 'academic_reference_unmapped';
        } else {
            $status = 'active_unmapped';
        }
        $counts[$status]++;
        $audit[] = $user + [
            'academic_participant' => $isacademic,
            'classification' => $status,
            'canonical_id' => is_array($mapping) ? (string)$mapping['canonical_id'] : '',
            'target_user_id' => is_array($mapping) ? (int)$mapping['target_user_id'] : null,
        ];
    }
    $missing = array_values(array_diff(array_keys($academic), array_keys($observedacademic)));
    sort($missing, SORT_NUMERIC);
    return [
        'schema_version' => '1.0',
        'source' => $sourceid,
        'academic_source_user_ids' => array_values(array_keys($academic)),
        'counts' => $counts,
        'missing_academic_user_ids' => $missing,
        'historical_map_conflicts' => $historicalmapconflicts,
        'blocked' => $counts['academic_reference_unmapped'] > 0 ||
            $counts['active_unmapped'] > 0 || $missing !== [] ||
            $historicalmapconflicts !== [],
        'users' => $audit,
    ];
}
