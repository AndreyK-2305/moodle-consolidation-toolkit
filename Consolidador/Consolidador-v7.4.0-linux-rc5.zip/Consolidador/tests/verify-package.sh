#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."

sha256sum --check --strict FILES.sha256
python3 - <<'PY'
from pathlib import Path
import re

entries = Path('FILES.sha256').read_text().splitlines()
listed = set()
for line in entries:
    match = re.fullmatch(r'[a-f0-9]{64}  (\./[^\n]+)', line)
    if match is None or match.group(1) in listed:
        raise SystemExit('FILES.sha256 contiene filas inválidas o repetidas')
    listed.add(match.group(1))
actual = {'./' + path.as_posix() for path in Path('.').rglob('*')
          if path.is_file() and path.as_posix() != 'FILES.sha256'}
if listed != actual:
    raise SystemExit(f'FILES.sha256 incompleto: faltan={sorted(actual-listed)} '
                     f'extras={sorted(listed-actual)}')
PY
find . -type f -name '*.sh' -print0 | xargs -0 -r -n 1 bash -n
find . -type f -name '*.php' -print0 | xargs -0 -r -n 1 php -l
php tests/contracts.php
php tests/rc2-contracts.php

pwsh -NoLogo -NoProfile -Command '
  $issues = @()
  Get-ChildItem scripts -Filter *.ps1 | ForEach-Object {
    $tokens = $null
    $errors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile(
      $_.FullName, [ref]$tokens, [ref]$errors
    )
    if ($errors) { $issues += $errors }
  }
  if ($issues.Count -gt 0) { $issues | Format-List; exit 1 }
'
pwsh -NoLogo -NoProfile -File tests/rc2-powershell.ps1
pwsh -NoLogo -NoProfile -File tests/rc3-powershell.ps1
pwsh -NoLogo -NoProfile -File tests/rc3-integration.ps1
pwsh -NoLogo -NoProfile -File tests/rc4-import.ps1
pwsh -NoLogo -NoProfile -File tests/rc4-wizard-retry.ps1
pwsh -NoLogo -NoProfile -File tests/rc5-startup.ps1
bash tests/rc5-launcher.sh

python3 - <<'PY'
import json
from pathlib import Path
import yaml

for path in Path('.').rglob('*.json'):
    if 'exports' not in path.parts and 'reports' not in path.parts:
        json.loads(path.read_text(encoding='utf-8-sig'))
yaml.safe_load(Path('compose.yaml').read_text())
print('JSON_YAML_OK')
PY

if command -v shellcheck >/dev/null 2>&1; then
    find . -type f -name '*.sh' -print0 | xargs -0 -r shellcheck
fi
printf '%s\n' DISTRIBUTION_OK
