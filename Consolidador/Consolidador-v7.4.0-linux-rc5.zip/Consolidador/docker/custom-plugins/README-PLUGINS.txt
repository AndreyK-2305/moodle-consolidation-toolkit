PLUGINS APROBADOS PARA MOODLE 5.2 (RC2)

Coloque el checkout Git de cada plugin en su ruta real dentro de Moodle 5.2,
por ejemplo public/mod/hvp o mod/hvp según la distribución. El repositorio
debe conservar .git; los submodules, incluido H5P cuando aplique, deben estar
inicializados recursivamente en commits concretos.

  git clone --recurse-submodules URL docker/custom-plugins/RUTA
  git -C docker/custom-plugins/RUTA checkout COMMIT_APROBADO
  git -C docker/custom-plugins/RUTA submodule update --init --recursive
  git -C docker/custom-plugins/RUTA status --porcelain
  git -C docker/custom-plugins/RUTA submodule status --recursive

El archivo approved-plugins.json declara un objeto por plugin adicional:
component, path, version, release, commit, tree_sha256, submodules. Para cada
submodule: path relativo al checkout, commit y tree_sha256. Se exige que la
versión, release y component coincidan literalmente con version.php, que el
checkout esté limpio, y que el árbol de archivos coincida con el hash aprobado.

El SHA-256 de árbol concatena, en orden lexicográfico, ruta relativa UTF-8,
NUL, SHA-256 hexadecimal del archivo, NUL; se omiten entradas .git. La función
pin_tree() de docker/verify-plugin-pins.php permite calcularlo durante una
revisión local. Registre previamente cada valor aprobado; nunca genere pins
automáticamente de un checkout no revisado.

La construcción de Docker se detiene ante directorios sin pin, commits sucios,
submodules ausentes o cambiados, diferencias en version.php o en los hashes.
La auditoría de fase 2 compara además el inventario instalado con los pins y
bloquea módulos utilizados aunque Moodle los haya deshabilitado.
