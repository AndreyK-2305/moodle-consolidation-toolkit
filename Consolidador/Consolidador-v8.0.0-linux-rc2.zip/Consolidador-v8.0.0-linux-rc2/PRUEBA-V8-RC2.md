# Protocolo de prueba V8 RC2

## Objetivo

Validar las correcciones RC2 sin alterar el flujo aprobado de RC1 ni la evidencia fuente.

## Validación automática de distribución

Desde la raíz extraída del paquete final:

```bash
./tests/verify-package.sh
```

Resultado obligatorio:

```text
DISTRIBUTION_OK
```

La suite comprueba checksums, sintaxis PHP, PowerShell y Bash, JSON/YAML, contratos acumulados y regresiones RC2.

## Escenarios RC2 cubiertos

1. Inicio limpio y ruta única de `destination-write.lock.json`.
2. Error de plugin con estado `WAITING_USER_ACTION`, revalidación y salida controlada.
3. Parser PowerShell con componentes de plugin y pins estrictos para plugins adicionales.
4. Espera/reintento de upgrade con éxito, timeout y evidencia de diagnóstico.
5. Evidencia OAuth derivada confinada bajo `/exports`.
6. Themes legibles por `www-data` y directorios de salida escribibles sin permisos `777`.
7. Selección foreground/background antes de Fase 13.
8. Plan previo de degradaciones, aprobación explícita y verificación de sellos.
9. Payload faltante aprobado: warning auditable, no fallo del worker.
10. Payload o diferencia estructural no aprobados: bloqueo.
11. Reanudación sin repetir fases ni análisis ya sellados.
12. Inmutabilidad de paquetes y MBZ de origen.

## Comprobación operativa recomendada

- Ejecutar primero con un destino limpio y los mismos paquetes/pins aprobados.
- Confirmar que el piloto, OAuth2 y themes concluyen antes de autorizar el lote.
- Revisar `exports/phase6/degradation_batch.json` y cada plan por curso.
- Aprobar o rechazar desde el wizard; no modificar manualmente los artefactos sellados.
- En segundo plano, comprobar progreso y warnings en los reportes de workers.
- Reanudar una ejecución interrumpida y confirmar que los checkpoints válidos se reutilizan.

## Criterios de rechazo

- Cualquier checksum, lint o contrato falla.
- Se modifica un paquete/MBZ fuente.
- Fase 13 inicia sin plan y aprobación válidos.
- Una inconsistencia desconocida se convierte en warning.
- El flujo vuelve automáticamente a plugins/OAuth/readiness después de la primera escritura.
- El paquete final extraído no termina con `DISTRIBUTION_OK`.
