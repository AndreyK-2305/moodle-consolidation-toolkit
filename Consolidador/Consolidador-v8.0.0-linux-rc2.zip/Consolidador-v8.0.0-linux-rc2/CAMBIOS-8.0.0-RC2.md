# Consolidador 8.0.0 Linux RC2

Base: `8.0.0-linux-rc1`.

Esta candidata aplica correcciones localizadas al flujo V8 sin modificar los paquetes fuente ni los MBZ originales.

## Cambios principales

- Unifica la ruta de `destination-write.lock.json` mediante `ConfigAccess.ps1` y conserva la máquina de estados monotónica después de la primera escritura.
- Corrige el parseo PowerShell de identificadores de plugin terminados en dos puntos.
- Mantiene el wizard en `WAITING_USER_ACTION` ante intervención de plugins y permite revalidar o salir sin marcar falsamente la ejecución como destruida.
- Añade espera/reintento acotado para upgrades del destino y exige pins completos antes de habilitar plugins adicionales.
- Admite evidencias OAuth derivadas bajo `/exports` sin relajar el confinamiento de rutas.
- Prepara permisos de transporte de themes para el consumidor real `www-data` y los valida antes del uso.
- Solicita explícitamente ejecución foreground/background antes del lote masivo; el modo queda ligado a los artefactos autorizados.
- Convierte Fase 12 en preflight de degradaciones sellado. Fase 13 consume únicamente planes aprobados y bloquea inconsistencias desconocidas.
- Diferencia `completed_with_warnings` de fallos: solo una omisión de payload aprobada puede continuar como warning auditado.
- Conserva checkpoints, hashes, reanudación y referencias livianas de backups.

## Contrato de degradaciones

- Los ZIP/MBZ fuente son evidencia inmutable.
- El análisis usa metadatos XML en caché y genera planes por curso más un resumen del lote.
- Una discrepancia estructural bloquea salvo resolución explícita por curso y relación.
- Una omisión aprobada se identifica por `file_id`; no se permiten omisiones implícitas ni reglas amplias.
- La aprobación está ligada por SHA-256 al lote, plan y autorización consumidos por los workers.

## Compatibilidad y migración

Los checkpoints válidos de RC1 se reutilizan cuando sus entradas y sellos siguen coincidiendo. Los artefactos nuevos de RC2 se recalculan una vez; no se repiten importación, plugins, OAuth, conciliación, piloto o preparación ya válidos.

## Validación

La distribución se entrega únicamente después de ejecutar `tests/verify-package.sh` sobre el ZIP final extraído y obtener `DISTRIBUTION_OK` con código de salida 0.
