$ErrorActionPreference = 'Stop'

function Assert-RC2Plugin([bool]$Condition, [string]$Message) {
    if (-not $Condition) { throw "V8_RC2_PLUGIN_FLOW_FAILED: $Message" }
}

$root = Split-Path -Parent $PSScriptRoot
$source = Join-Path $root 'scripts/audit-package-plugins.ps1'
$tokens = $null
$errors = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile(
    $source, [ref]$tokens, [ref]$errors
)
Assert-RC2Plugin ($errors.Count -eq 0) 'audit-package-plugins.ps1 no parsea'
$requiredFunctions = @(
    'Test-ApprovedAdditionalPlugin',
    'Enable-RequiredDisabledActivityModules',
    'Invoke-DestinationUpgradeWait'
)
foreach ($name in $requiredFunctions) {
    $definition = @($ast.FindAll({
        param($node)
        $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and
            $node.Name -eq $name
    }, $true))
    Assert-RC2Plugin ($definition.Count -eq 1) "no encontró función $name"
    Invoke-Expression $definition[0].Extent.Text
}

$temp = Join-Path ([IO.Path]::GetTempPath()) (
    'v8-rc2-plugin-flow-' + [guid]::NewGuid().ToString('N')
)
$oldPath = $env:PATH
$oldTimeout = $env:PLUGIN_UPGRADE_WAIT_TIMEOUT_SECONDS
$oldRetry = $env:PLUGIN_UPGRADE_RETRY_SECONDS
$oldLog = $env:V8RC2_DOCKER_LOG
$oldState = $env:V8RC2_UPGRADE_STATE
$oldAlways = $env:V8RC2_ALWAYS_UPGRADE
try {
    New-Item -ItemType Directory -Force -Path $temp | Out-Null
    $docker = Join-Path $temp 'docker'
    @'
#!/usr/bin/env bash
set -eu
printf '%s\n' "$*" >> "$V8RC2_DOCKER_LOG"
if [[ "$*" == *"upgrade.php"* ]]; then
  if [[ "${V8RC2_ALWAYS_UPGRADE:-0}" == "1" ]]; then
    printf '%s\n' 'El sitio está siendo actualizado'
    exit 1
  fi
  count=0
  if [[ -f "$V8RC2_UPGRADE_STATE" ]]; then count="$(cat "$V8RC2_UPGRADE_STATE")"; fi
  count=$((count + 1))
  printf '%s' "$count" > "$V8RC2_UPGRADE_STATE"
  if [[ "$count" -eq 1 ]]; then
    printf '%s\n' 'site is being upgraded'
    exit 1
  fi
  exit 0
fi
if [[ "$*" == *"php -r"* ]]; then
  printf '%s\n' 'DESTINATION_READY'
  exit 0
fi
if [[ "$*" == *"target-enable-plugin.php"* ]]; then
  printf '%s\n' 'TARGET_PLUGIN_ENABLED'
  exit 0
fi
exit 0
'@ | Set-Content -LiteralPath $docker -Encoding utf8NoBOM
    & /bin/chmod 0755 $docker
    $env:PATH = "$temp$([IO.Path]::PathSeparator)$oldPath"
    $env:V8RC2_DOCKER_LOG = Join-Path $temp 'docker.log'
    $env:V8RC2_UPGRADE_STATE = Join-Path $temp 'upgrade.state'
    $env:PLUGIN_UPGRADE_WAIT_TIMEOUT_SECONDS = '5'
    $env:PLUGIN_UPGRADE_RETRY_SECONDS = '1'
    $service = 'moodle-target'

    $eventText = (& {
        $script:waitResult = Invoke-DestinationUpgradeWait
    } 6>&1 | Out-String)
    Assert-RC2Plugin ($waitResult.Ready -and $waitResult.Attempts -eq 2) `
        'upgrade transitorio no hizo WAIT → retry → READY'
    Assert-RC2Plugin ($eventText -match 'DESTINATION_UPGRADE_WAIT' -and
        $eventText -match 'DESTINATION_UPGRADE_READY') `
        'faltan eventos auditables WAIT/READY'

    $env:V8RC2_ALWAYS_UPGRADE = '1'
    $env:PLUGIN_UPGRADE_WAIT_TIMEOUT_SECONDS = '1'
    $timedOut = $false
    try { Invoke-DestinationUpgradeWait | Out-Null }
    catch { $timedOut = $_.Exception.Message -match 'PLUGIN_UPGRADE_WAIT_TIMEOUT' }
    Assert-RC2Plugin $timedOut 'upgrade infinito no terminó por timeout'
    $env:V8RC2_ALWAYS_UPGRADE = '0'

    $plugin = [pscustomobject]@{
        component = 'mod_chat'; source = 'additional'; version_disk = '2026092700'
        approved_commit = 'abc123'; tree_sha256 = ('a' * 64); release = '8.0'
    }
    $pin = [pscustomobject]@{
        component = 'mod_chat'; version = '2026092700'; commit = 'abc123'
        tree_sha256 = ('a' * 64); release = '8.0'
    }
    $inventory = [pscustomobject]@{
        plugins = @($plugin); approved_plugins = @($pin)
    }
    $needs = @([pscustomobject]@{
        component = 'mod_chat'; used_activity = $true
        observed_state = 'installed_disabled'
    })
    $pinEvents = (& {
        Enable-RequiredDisabledActivityModules $needs $inventory
    } 6>&1 | Out-String)
    $dockerLog = Get-Content -LiteralPath $env:V8RC2_DOCKER_LOG -Raw
    Assert-RC2Plugin ($pinEvents -match 'TARGET_PLUGIN_PIN_VERIFIED' -and
        $dockerLog -match '--component=mod_chat' -and
        $dockerLog -match '--pin-verified=1') `
        'plugin adicional pinned no fue habilitado con evidencia estricta'

    $inventory.approved_plugins = @()
    $blocked = $false
    try { Enable-RequiredDisabledActivityModules $needs $inventory }
    catch { $blocked = $_.Exception.Message -match 'PLUGIN_PIN_REQUIRED' }
    Assert-RC2Plugin $blocked 'plugin adicional sin pin no bloqueó'

    Write-Output 'V8_RC2_PLUGIN_FLOW_OK wait=retry ready=2 timeout=bounded pinned=enabled unpinned=blocked'
} finally {
    $env:PATH = $oldPath
    $env:PLUGIN_UPGRADE_WAIT_TIMEOUT_SECONDS = $oldTimeout
    $env:PLUGIN_UPGRADE_RETRY_SECONDS = $oldRetry
    $env:V8RC2_DOCKER_LOG = $oldLog
    $env:V8RC2_UPGRADE_STATE = $oldState
    $env:V8RC2_ALWAYS_UPGRADE = $oldAlways
    Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue
}
