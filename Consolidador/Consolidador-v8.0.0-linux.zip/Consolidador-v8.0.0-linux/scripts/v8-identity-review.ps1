param(
    [ValidateSet('Prepare', 'Apply')]
    [string]$Mode = 'Prepare'
)

$ErrorActionPreference = 'Stop'
. "$PSScriptRoot/Common.ps1"
$candidates = Join-Path $ProjectRoot 'exports/identity_candidates.csv'
$review = Join-Path $ProjectRoot 'exports/identity_candidate_review.csv'
$output = Join-Path $ProjectRoot 'config/fuzzy_identity_resolutions.csv'
$engine = Join-Path $ProjectRoot 'scripts/v8-identity-review.php'

if (-not (Test-Path -LiteralPath $candidates -PathType Leaf)) {
    throw 'V8_IDENTITY_CANDIDATES_MISSING'
}
if ($Mode -eq 'Prepare') {
    if (-not (Test-Path -LiteralPath $review -PathType Leaf)) {
        Copy-Item -LiteralPath $candidates -Destination $review
    }
    Write-Host 'Revise exports\identity_candidate_review.csv.' -ForegroundColor Yellow
    Write-Host 'Complete resolution=MERGE|KEEP_SEPARATE|IGNORE y los campos de auditoría.'
    Write-Host 'Después ejecute: pwsh scripts/v8-identity-review.ps1 -Mode Apply'
    return
}
if (-not (Test-Path -LiteralPath $review -PathType Leaf)) {
    throw 'V8_IDENTITY_REVIEW_FILE_MISSING'
}
& php $engine "--candidates=$candidates" "--review=$review" "--output=$output"
if ($LASTEXITCODE -ne 0) { throw 'V8_IDENTITY_REVIEW_IMPORT_FAILED' }
Write-Host 'Decisiones importadas. Reanude INICIAR-CONSOLIDACION.sh.' -ForegroundColor Green
Write-Host 'Fase 3 y Fase 4 se regenerarán por sus hashes antes de READY_TO_RUN.'
