#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."

fixture="$(mktemp -d -t rc5-launcher-XXXXXXXX)"
cleanup() {
  rm -rf -- "${fixture}"
}
trap cleanup EXIT

# La copia conserva el árbol exacto del paquete que ejecuta verify-package.sh.
# La infraestructura simulada llega al pwsh real sin tocar Docker ni Moodle.
cp -a . "${fixture}/Consolidador"
project="${fixture}/Consolidador"
mkdir -p "${fixture}/bin" "${project}/copias"
cat > "${project}/.env" <<'ENV'
MOODLE_PUBLIC_URL=https://moodle.example.edu
MOODLE_INTERNAL_HEALTH_URL=http://127.0.0.1:8090
MOODLE_ADMIN_PASSWORD=ValidPassword123@
CONSOLIDATION_EMAIL_ENABLED=0
ENV
touch "${project}/copias/origen1.zip" "${project}/copias/origen2.zip"
cat > "${project}/scripts/import-source-packages.ps1" <<'PS'
Write-Host 'RC5_LAUNCHER_PHASE1_ENTERED'
throw 'RC5_LAUNCHER_STOP_TEST'
PS
cat > "${fixture}/bin/docker" <<'MOCK'
#!/usr/bin/env bash
set -Eeuo pipefail
if [[ "${1:-}" == info ]]; then exit 0; fi
if [[ "${1:-}" == inspect ]]; then
  case "${3:-}" in
    *Health*) printf 'healthy\n' ;;
    *) printf 'running\n' ;;
  esac
  exit 0
fi
[[ "${1:-}" == compose ]] || exit 78
shift
if [[ "${1:-}" == version ]]; then exit 0; fi
[[ "${1:-}" == --project-name ]] || exit 78
shift 2
case "${1:-}" in
  config)
    [[ "${2:-}" == --format && "${3:-}" == json ]] || exit 78
    printf '{"services":{"assistant-runtime":{"working_dir":"%s","environment":{"ASSISTANT_PROJECT_ROOT":"%s"},"volumes":[{"type":"bind","source":"%s","target":"%s"}]}}}\n' \
      "${ASSISTANT_PROJECT_ROOT}" "${ASSISTANT_PROJECT_ROOT}" "${ASSISTANT_PROJECT_ROOT}" "${ASSISTANT_PROJECT_ROOT}"
    printf '%s\n' "${ASSISTANT_PROJECT_ROOT}" > "${MOCK_ASSISTANT_ROOT_LOG}"
    ;;
  ps) printf 'rc5-target-container\n' ;;
  build) exit 0 ;;
  run)
    while (($#)); do
      if [[ "$1" == pwsh ]]; then exec "$@"; fi
      shift
    done
    exit 78
    ;;
  *) exit 78 ;;
esac
MOCK
chmod +x "${fixture}/bin/docker"

# Este runtime de pruebas no permite crear sockets Unix. Solo en la copia del
# fixture se acepta un archivo regular para superar la comprobación del socket;
# toda la ruta del entrypoint, Compose simulado y el pwsh real sigue ejecutándose.
socket="${fixture}/mock-docker.sock"
touch "${socket}"
python3 - "${project}/moodle-consolidation.sh" <<'PY'
from pathlib import Path
import sys
path = Path(sys.argv[1])
text = path.read_text()
old = '[[ -S "${socket_path}" ]] ||'
if text.count(old) != 1:
    raise SystemExit('RC5_LAUNCHER_FAILED falta el control de socket conocido')
path.write_text(text.replace(old, '[[ -e "${socket_path}" ]] ||', 1))
PY
[[ -f "${socket}" && ! -e "${project}/config.yaml" ]] ||
  { printf 'RC5_LAUNCHER_FAILED fixture sin arranque limpio\n' >&2; exit 1; }

set +e
(
  cd "${project}"
  printf 'continuar\nsalir\n' | ASSISTANT_PROJECT_ROOT="${fixture}/Consolidador-rc5" \
    MOCK_ASSISTANT_ROOT_LOG="${fixture}/assistant-root.log" DOCKER_HOST="unix://${socket}" \
    PATH="${fixture}/bin:${PATH}" ./INICIAR-CONSOLIDACION.sh
) > "${fixture}/stdout.log" 2>&1
status="$?"
set -e
if [[ "${status}" -ne 0 ]] ||
    ! rg -q 'DESTINO_LISTO' "${fixture}/stdout.log" ||
    ! rg -q 'RC5_LAUNCHER_PHASE1_ENTERED' "${fixture}/stdout.log" ||
    rg -q 'No se encontró config.yaml' "${fixture}/stdout.log" ||
    [[ -e "${project}/config.yaml" ]]; then
  cat "${fixture}/stdout.log" >&2
  printf 'RC5_LAUNCHER_FAILED status=%s\n' "${status}" >&2
  exit 1
fi
[[ "$(cat "${fixture}/assistant-root.log")" == "${project}" ]] ||
  { printf 'RC7_PROJECT_ROOT_FAILED runtime heredó otro proyecto\n' >&2; exit 1; }
python3 - "${project}/reports/assistant-state.json" <<'PY'
import json, sys
state = json.load(open(sys.argv[1], encoding='utf-8'))
if state['stage'] != '01-importar-paquetes' or state['status'] != 'paused':
    raise SystemExit('RC5_LAUNCHER_FAILED estado de Fase 1 incorrecto')
PY
printf 'RC5_LAUNCHER_OK entrypoint=1 target_mock=healthy phase1_without_config=1\n'
