<?php
// Registro de identidades históricas reutilizadas entre restauraciones.
declare(strict_types=1);

function p6_historical_source_ids(array $classification, array $globalmap): array {
    $source = (string)($classification['source'] ?? '');
    $ids = [];
    foreach ($classification['users'] ?? [] as $row) {
        if (($row['classification'] ?? '') !== 'historical_deleted') {
            continue;
        }
        $userid = (int)$row['source_user_id'];
        if ($userid < 1 || !($row['deleted'] ?? false) ||
                isset($globalmap[$source . ':' . $userid]) ||
                (int)($row['target_user_id'] ?? 0) > 0 ||
                (string)($row['canonical_id'] ?? '') !== '') {
            throw new RuntimeException('historical_user_reactivated: clasificación o Phase4 inválidos.');
        }
        $ids[$userid] = true;
    }
    $result = array_map('intval', array_keys($ids));
    sort($result, SORT_NUMERIC);
    return $result;
}

function p6_historical_registry_path(string $phase6dir, string $source, int $userid): string {
    if (!preg_match('/^[a-z][a-z0-9_-]*$/', $source) || $userid < 1) {
        throw new RuntimeException('Clave histórica inválida.');
    }
    return rtrim($phase6dir, '/\\') . '/historical-users/' . $source . '-' . $userid . '.json';
}

function p6_historical_assert_disjoint(array $idsbytarget, array $globalmap): void {
    $activeids = [];
    foreach ($globalmap as $mapping) {
        $activeids[(int)($mapping['target_user_id'] ?? 0)] = true;
    }
    $seen = [];
    foreach ($idsbytarget as $sourceid => $targetid) {
        if ((int)$targetid < 1 || isset($activeids[(int)$targetid]) ||
                isset($seen[(int)$targetid])) {
            throw new RuntimeException(
                'historical_user_duplicated: fusión con usuario activo o histórico.'
            );
        }
        $seen[(int)$targetid] = (int)$sourceid;
    }
}

function p6_historical_registry_update(
    ?array $previous, string $source, int $userid, int $targetid, string $coursekey
): array {
    if ($userid < 1 || $targetid < 1 || $coursekey === '') {
        throw new RuntimeException('historical_history_lost: falta resolución del usuario.');
    }
    if ($previous !== null &&
            (($previous['source_id'] ?? '') !== $source ||
             (int)($previous['source_user_id'] ?? 0) !== $userid ||
             (int)($previous['target_user_id'] ?? 0) !== $targetid)) {
        throw new RuntimeException('historical_user_duplicated: el destino histórico cambió.');
    }
    $courses = $previous['observed_course_keys'] ?? [];
    $courses[] = $coursekey;
    $courses = array_values(array_unique($courses));
    sort($courses, SORT_STRING);
    return [
        'schema_version' => '1.0', 'phase' => '6-historical-user-registry',
        'source_id' => $source, 'source_user_id' => $userid,
        'target_user_id' => $targetid,
        'resolution' => 'moodle_backup_ids_user_mapping',
        'observed_course_keys' => $courses,
    ];
}

function p6_historical_assert_target(object $db, int $targetid): array {
    $record = $db->get_record('user', ['id' => $targetid],
        'id,username,email,auth,deleted', IGNORE_MISSING);
    if (!$record) {
        throw new RuntimeException('historical_history_lost: usuario destino inexistente.');
    }
    if ((int)$record->deleted !== 1 || (string)$record->auth === 'oauth2') {
        throw new RuntimeException('historical_user_reactivated: usuario activo u OAuth.');
    }
    if ($db->get_manager()->table_exists('auth_oauth2_linked_login') &&
            $db->record_exists('auth_oauth2_linked_login', ['userid' => $targetid])) {
        throw new RuntimeException('historical_user_reactivated: vínculo OAuth en usuario eliminado.');
    }
    foreach (['google_sub', 'migration_identity_status'] as $field) {
        $fieldrow = $db->get_record('user_info_field', ['shortname' => $field], 'id', IGNORE_MISSING);
        if (!$fieldrow) {
            continue;
        }
        $data = $db->get_field('user_info_data', 'data', [
            'fieldid' => (int)$fieldrow->id, 'userid' => $targetid,
        ]);
        if ($field === 'google_sub' && trim((string)$data) !== '' ||
                $field === 'migration_identity_status' &&
                trim((string)$data) === 'pending_relink') {
            throw new RuntimeException('historical_user_reactivated: identidad OAuth o pending_relink.');
        }
    }
    return [
        'target_user_id' => $targetid, 'deleted' => true,
        'auth' => (string)$record->auth, 'username' => (string)$record->username,
        'email' => (string)$record->email, 'oauth_links' => 0,
    ];
}

function p6_historical_relation_issues(
    array $sourceinventory, array $targetinventory, array $idsbytarget
): array {
    $issues = [];
    foreach ($idsbytarget as $sourceid => $targetid) {
        foreach (($sourceinventory['relations'] ?? []) as $relation => $rows) {
            $actualrows = $targetinventory['relations'][$relation] ?? [];
            if ($relation === 'files') {
                $rows = p5_filter_comparable_files($rows);
                $actualrows = p5_filter_comparable_files($actualrows);
            }
            if ($relation === 'course_completions') {
                $rows = array_values(array_filter($rows,
                    static fn(array $row): bool => ($row['completed'] ?? false) === true));
                $actualrows = array_values(array_filter($actualrows,
                    static fn(array $row): bool => ($row['completed'] ?? false) === true));
            }
            $signature = static function(array $candidates, int $userid): array {
                $counts = [];
                foreach ($candidates as $row) {
                    if ((int)($row['source_user_id'] ?? 0) !== $userid) {
                        continue;
                    }
                    unset($row['source_user_id'], $row['attempt_id'], $row['quiz_id'],
                        $row['source_module_id']);
                    $key = json_encode($row, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES |
                        JSON_THROW_ON_ERROR);
                    $counts[$key] = ($counts[$key] ?? 0) + 1;
                }
                ksort($counts, SORT_STRING);
                return $counts;
            };
            $expected = $signature($rows, (int)$sourceid);
            $actual = $signature($actualrows, (int)$targetid);
            if ($expected !== $actual) {
                $issues[] = [
                    'error' => 'historical_history_lost', 'source_user_id' => (int)$sourceid,
                    'target_user_id' => (int)$targetid, 'relation' => $relation,
                    'expected' => $expected, 'actual' => $actual,
                ];
            }
        }
    }
    return $issues;
}
