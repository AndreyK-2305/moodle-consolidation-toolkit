<?php
// Sustituto mínimo para probar los contratos puros sin iniciar Moodle.
