#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."

sha256sum --check --strict FILES.sha256
python3 - <<'PY'
from pathlib import Path
import re

entries = Path('FILES.sha256').read_text().splitlines()
listed = set()
for line in entries:
    match = re.fullmatch(r'[a-f0-9]{64}  (\./[^\n]+)', line)
    if match is None or match.group(1) in listed:
        raise SystemExit('FILES.sha256 contiene filas inválidas o repetidas')
    listed.add(match.group(1))
actual = {'./' + path.as_posix() for path in Path('.').rglob('*')
          if path.is_file() and path.as_posix() != 'FILES.sha256'}
if listed != actual:
    raise SystemExit(f'FILES.sha256 incompleto: faltan={sorted(actual-listed)} '
                     f'extras={sorted(listed-actual)}')
for path in Path('.').rglob('*'):
    if not path.is_file():
        continue
    name = path.as_posix()
    if ('.git' in path.parts or path.name in ('.env',) or
            path.suffix.lower() in ('.bak', '.pem', '.zip', '.sql') or
            (path.parts[0] == 'exports' and name != 'exports/LEEME.txt') or
            (path.parts[0] == 'reports' and name != 'reports/LEEME.txt') or
            (path.parts[0] == 'copias' and name != 'copias/COLOQUE-AQUI-LOS-ZIP.txt')):
        raise SystemExit(f'DISTRIBUTION_CONTENT_INVALID: {name}')
PY
find . -type f -name '*.sh' -print0 | xargs -0 -r -n 1 bash -n
find . -type f -name '*.php' -print0 | xargs -0 -r -n 1 php -l
php tests/contracts.php
php tests/rc2-contracts.php
php tests/rc11-email-normalization.php
php tests/rc11-resolution-regression.php
php tests/rc12-managed-config.php
php tests/rc12-shared-email.php
php tests/rc10-plugin-pins.php
php tests/rc14-module-identities.php
php tests/rc15-relation-reconciliation.php
php tests/rc16-file-context-population.php
php tests/rc17-activity-contexts.php
php tests/rc17-editpdf-contract.php

pwsh -NoLogo -NoProfile -Command '
  $issues = @()
  Get-ChildItem scripts -Filter *.ps1 | ForEach-Object {
    $tokens = $null
    $errors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile(
      $_.FullName, [ref]$tokens, [ref]$errors
    )
    if ($errors) { $issues += $errors }
  }
  if ($issues.Count -gt 0) { $issues | Format-List; exit 1 }
'
pwsh -NoLogo -NoProfile -File tests/rc2-powershell.ps1
pwsh -NoLogo -NoProfile -File tests/rc3-powershell.ps1
pwsh -NoLogo -NoProfile -File tests/rc7-plugin-dependencies.ps1
pwsh -NoLogo -NoProfile -File tests/rc10-release.ps1
pwsh -NoLogo -NoProfile -File tests/rc9-moodle-versions.ps1
pwsh -NoLogo -NoProfile -File tests/rc9-revalidate-integration.ps1
pwsh -NoLogo -NoProfile -File tests/rc10-plugin-retry.ps1
pwsh -NoLogo -NoProfile -File tests/rc3-integration.ps1
pwsh -NoLogo -NoProfile -File tests/rc4-import.ps1
pwsh -NoLogo -NoProfile -File tests/rc4-wizard-retry.ps1
pwsh -NoLogo -NoProfile -File tests/rc13-wizard-paths.ps1
pwsh -NoLogo -NoProfile -File tests/rc5-startup.ps1
bash tests/rc5-launcher.sh
bash tests/rc6-stop.sh
python3 tests/rc17-runtime-tags.py
python3 tests/rc12-env-migration.py

python3 - <<'PY'
import json
from pathlib import Path
import yaml

for path in Path('.').rglob('*.json'):
    if 'exports' not in path.parts and 'reports' not in path.parts:
        json.loads(path.read_text(encoding='utf-8-sig'))
yaml.safe_load(Path('compose.yaml').read_text())
print('JSON_YAML_OK')
PY

if command -v shellcheck >/dev/null 2>&1; then
    find . -type f -name '*.sh' -print0 | xargs -0 -r shellcheck
fi
printf '%s\n' DISTRIBUTION_OK
