﻿param(
    [string]$AssistantApproval = ""
)

. "$PSScriptRoot/Common.ps1"

Assert-ConfigurationConfirmed
Assert-Command "docker"
& docker info *> $null
if ($LASTEXITCODE -ne 0) {
    throw "Docker Engine no está iniciado o no responde."
}

$phase6Host = Join-Path $ProjectRoot "exports\phase6"
$manifestPath = Join-Path $phase6Host "batch_manifest.json"
if (-not (Test-Path $manifestPath -PathType Leaf)) {
    throw "Falta exports\phase6\batch_manifest.json. Ejecute primero el comando 20."
}
$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 |
    ConvertFrom-Json
if ([string]$manifest.manifest_status -ne "prepared" -or
        [int]$manifest.courses_pending -ne 0 -or
        [bool]$manifest.destination_write_performed) {
    throw "El manifiesto no está preparado o perdió su condición de solo lectura."
}

$targetSite = Get-TargetSite
$targetService = [string]$targetSite.service
$configHash = Get-ConfigurationHash
$expectLab = if ($MigrationConfig.Mode -eq "lab") { "1" } else { "0" }
$report = Join-Path $ProjectRoot "reports\fase-6-aplicacion-lote.txt"

Invoke-Compose -Arguments @("up", "-d", "--no-build", $targetService)
$scripts = @(
    "phase5-lib.php",
    "phase6-lib.php",
    "phase6-apply-preflight.php",
    "phase6-apply-categories.php",
    "phase6-apply-course.php",
    "phase6-seal-apply.php"
)
foreach ($scriptName in $scripts) {
    & docker compose cp "scripts/$scriptName" "${targetService}:/tmp/$scriptName"
    if ($LASTEXITCODE -ne 0) {
        throw "No fue posible copiar $scriptName al Moodle destino."
    }
}
Grant-ContainerExportWrite `
    -Service $targetService `
    -ContainerPath "/exports/phase6" `
    -ChildDirectories @(
        "backups/normalized",
        "normalization-audits",
        "target-inventories",
        "apply-states",
        "apply-checkpoints",
        "restore-diagnostics"
    )

Write-Host "Revalidando manifiesto, usuarios, piloto y estado actual del destino..." -ForegroundColor Cyan
$previousErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = "Continue"
try {
    $preflightOutput = & docker compose exec -T -u www-data $targetService `
        php /tmp/phase6-apply-preflight.php `
        "--phase4=/exports/phase4" `
        "--phase6=/exports/phase6" `
        "--configsha=$configHash" `
        "--targetid=$($targetSite.id)" `
        "--expectlab=$expectLab" 2>&1
    $preflightExit = $LASTEXITCODE
} finally {
    $ErrorActionPreference = $previousErrorActionPreference
}
Restore-AssistantExportOwnership -Service $targetService -ContainerPath "/exports/phase6"
$preflightOutput | Tee-Object -FilePath $report
if ($preflightExit -ne 0) {
    throw "La prevalidación de aplicación falló. Revise $report."
}
$preflight = Get-Content `
    -LiteralPath (Join-Path $phase6Host "apply_preflight.json") `
    -Raw `
    -Encoding UTF8 |
    ConvertFrom-Json

Write-Host ""
Write-Host "FASE 6: aplicación controlada del lote" -ForegroundColor Yellow
Write-Host "Lote: $($manifest.batch_id)" -ForegroundColor Yellow
Write-Host "Cursos totales: $($preflight.courses_expected)" -ForegroundColor Yellow
Write-Host "Cursos ya aplicados: $($preflight.courses_already_applied)" -ForegroundColor Yellow
Write-Host "Cursos pendientes: $($preflight.courses_pending)" -ForegroundColor Yellow
Write-Host "Curso piloto conservado: $($preflight.pilot_course_id)" -ForegroundColor Yellow
$manifestHash = (
    Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256
).Hash.ToLowerInvariant()
if ([string]::IsNullOrWhiteSpace($AssistantApproval)) {
    $confirmation = Read-Host "Escriba exactamente APLICAR FASE 6 para continuar"
    if ($confirmation -cne "APLICAR FASE 6") {
        Write-Host "Operación cancelada. La prevalidación no modificó Moodle." -ForegroundColor Yellow
        exit 0
    }
} else {
    $expectedApproval = "ASSISTANT-PHASE6-$manifestHash"
    if ($AssistantApproval -cne $expectedApproval) {
        throw "La autorización interna del asistente no corresponde al manifiesto."
    }
    Write-Host "Autorización guiada verificada contra el SHA-256 del manifiesto." -ForegroundColor Green
}

Register-DestinationWriteIntent `
    -Phase "phase6-batch" `
    -BoundHash $manifestHash

Write-Host "Creando o reutilizando jerarquía y rol personalizado seguro..." -ForegroundColor Cyan
Grant-ContainerExportWrite -Service $targetService -ContainerPath "/exports/phase6"
$previousErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = "Continue"
try {
    $categoryOutput = & docker compose exec -T -u www-data $targetService `
        php /tmp/phase6-apply-categories.php `
        "--phase4=/exports/phase4" `
        "--phase6=/exports/phase6" `
        "--configsha=$configHash" `
        "--targetid=$($targetSite.id)" `
        "--expectlab=$expectLab" 2>&1
    $categoryExit = $LASTEXITCODE
} finally {
    $ErrorActionPreference = $previousErrorActionPreference
}
Restore-AssistantExportOwnership -Service $targetService -ContainerPath "/exports/phase6"
$categoryOutput | Out-File -FilePath $report -Append -Encoding UTF8
$categoryOutput | ForEach-Object { Write-Host $_ }
if ($categoryExit -ne 0) {
    throw "No fue posible aplicar la jerarquía. Revise $report."
}

$courses = @(
    Import-Csv `
        -LiteralPath (Join-Path $phase6Host "course_plan.csv") `
        -Encoding UTF8 |
    Where-Object { [string]$_.action -eq "restore_new" } |
    Sort-Object -Property @(
        "source"
        @{ Expression = { [int]$_.source_course_id } }
    )
)
if ($courses.Count -ne [int]$manifest.courses_expected) {
    throw "course_plan.csv no conserva los cursos del manifiesto."
}
Grant-ContainerExportWrite -Service $targetService -ContainerPath "/exports/phase6"

$position = 0
foreach ($course in $courses) {
    $position++
    $status = "$($course.source): $($course.source_shortname)"
    Write-Progress `
        -Activity "Aplicando curso $position de $($courses.Count)" `
        -Status $status `
        -PercentComplete (($position / $courses.Count) * 100)
    Write-Host "[$position/$($courses.Count)] $status" -ForegroundColor Cyan
    $previousErrorActionPreference = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
        $courseOutput = & docker compose exec -T -u www-data $targetService `
            php /tmp/phase6-apply-course.php `
            "--phase4=/exports/phase4" `
            "--phase6=/exports/phase6" `
            "--configsha=$configHash" `
            "--targetid=$($targetSite.id)" `
            "--targeturl=$($targetSite.url)" `
            "--coursekey=$($course.course_key)" `
            "--expectlab=$expectLab" 2>&1
        $courseExit = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $previousErrorActionPreference
    }
    $courseOutput | Out-File -FilePath $report -Append -Encoding UTF8
    $courseOutput | ForEach-Object { Write-Host $_ }
    if ($courseExit -ne 0) {
        Write-Progress -Activity "Aplicando cursos" -Completed
        Restore-AssistantExportOwnership `
            -Service $targetService `
            -ContainerPath "/exports/phase6"
        throw (
            "La aplicación se detuvo en $($course.course_key). " +
            "Los checkpoints anteriores se conservan; revise $report y repita el comando 21."
        )
    }
}
Write-Progress -Activity "Aplicando cursos" -Completed

Write-Host "Sellando la aplicación completa del lote..." -ForegroundColor Cyan
$previousErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = "Continue"
try {
    $sealOutput = & docker compose exec -T -u www-data $targetService `
        php /tmp/phase6-seal-apply.php `
        "--phase4=/exports/phase4" `
        "--phase6=/exports/phase6" `
        "--configsha=$configHash" `
        "--targetid=$($targetSite.id)" `
        "--expectlab=$expectLab" 2>&1
    $sealExit = $LASTEXITCODE
} finally {
    $ErrorActionPreference = $previousErrorActionPreference
}
Restore-AssistantExportOwnership -Service $targetService -ContainerPath "/exports/phase6"
$sealOutput | Out-File -FilePath $report -Append -Encoding UTF8
$sealOutput | ForEach-Object { Write-Host $_ }
if ($sealExit -ne 0) {
    throw "No fue posible sellar la aplicación. Revise $report."
}

$summary = Get-Content `
    -LiteralPath (Join-Path $phase6Host "batch_apply_summary.json") `
    -Raw `
    -Encoding UTF8 |
    ConvertFrom-Json
Write-Host ""
Write-Host "FASE 6 aplicada de forma controlada." -ForegroundColor Green
Write-Host "Cursos aplicados: $($summary.courses_applied)." -ForegroundColor Cyan
Write-Host "Cursos pendientes: $($summary.courses_pending)." -ForegroundColor Cyan
Write-Host "Curso piloto excluido: $($summary.pilot_excluded)." -ForegroundColor Cyan
Write-Host "Estado: $($summary.apply_status)." -ForegroundColor Cyan
Write-Host "Cada curso quedó validado y con checkpoint reanudable." -ForegroundColor Green
