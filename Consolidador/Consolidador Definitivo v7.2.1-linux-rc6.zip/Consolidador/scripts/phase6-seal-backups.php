<?php
// Fase 6: verifica todos los checkpoints y sella el manifiesto de backups crudos.

declare(strict_types=1);

define('CLI_SCRIPT', true);

require('/var/www/html/config.php');
require_once($CFG->libdir . '/clilib.php');
require_once($CFG->libdir . '/filelib.php');
require_once('/tmp/phase5-lib.php');
require_once('/tmp/phase6-lib.php');

[$options, $unrecognized] = cli_get_params(
    [
        'phase4' => '/exports/phase4',
        'phase6' => '/exports/phase6',
        'configsha' => null,
        'targetid' => null,
        'expectlab' => 0,
        'help' => false,
    ],
    ['h' => 'help']
);
if ($options['help']) {
    cli_writeln(
        "Uso: php phase6-seal-backups.php --phase4=/exports/phase4 " .
        "--phase6=/exports/phase6 --configsha=SHA256 --targetid=target " .
        "[--expectlab=1]\n"
    );
    exit(0);
}
if ($unrecognized) {
    cli_error('Opciones no reconocidas: ' . implode(', ', $unrecognized));
}

try {
    $phase4dir = rtrim((string)$options['phase4'], '/\\');
    $phase6dir = rtrim((string)$options['phase6'], '/\\');
    $configsha = p5_require_sha256((string)$options['configsha'], 'configsha');
    $targetid = p5_norm((string)$options['targetid']);
    $expectlab = (bool)(int)$options['expectlab'];
    if (!preg_match('/^[a-z][a-z0-9_-]*$/', $targetid)) {
        throw new RuntimeException('targetid inválido.');
    }
    $bundle = p6_load_inventory_plan(
        $phase4dir,
        $phase6dir,
        $configsha,
        $targetid,
        $expectlab
    );

    $entries = [];
    $progressrows = [];
    $expectedcheckpointnames = [];
    $totalbytes = 0;
    $totalusers = 0;
    $totalmappedusers = 0;
    $totalreservedusers = 0;
    $totalplannedsourceusers = 0;
    $zeroparticipantcourses = 0;
    $totalmerges = 0;
    $totalquestioncategories = 0;
    foreach ($bundle['restore_courses'] as $courseplan) {
        $coursekey = (string)$courseplan['course_key'];
        $plannedsourceusers = count(
            p6_expected_course_source_user_ids($bundle, $coursekey)
        );
        $basename = p6_backup_basename($coursekey);
        $rawpath = $phase6dir . '/backups/raw/raw-' . $basename . '.mbz';
        $inventorypath =
            $phase6dir . '/course-inventories/inventory-' . $basename . '.json';
        $auditpath =
            $phase6dir . '/backup-audits/audit-' . $basename . '.json';
        $checkpointpath =
            $phase6dir . '/backup-checkpoints/checkpoint-' . $basename . '.json';
        $expectedcheckpointnames[] = basename($checkpointpath);
        $checkpoint = p5_read_json($checkpointpath);
        $files = [
            'raw_backup' => $rawpath,
            'source_inventory' => $inventorypath,
            'backup_audit' => $auditpath,
        ];
        $filehashes = p5_hash_files($files);
        $checkpointhashes = $checkpoint['files_sha256'] ?? [];
        if (!is_array($checkpointhashes)) {
            throw new RuntimeException(
                'El checkpoint de ' . $coursekey . ' no contiene hashes.'
            );
        }
        ksort($checkpointhashes, SORT_STRING);
        if (($checkpoint['schema_version'] ?? '') !== '1.0' ||
                ($checkpoint['phase'] ?? '') !== '6-course-backup-checkpoint' ||
                ($checkpoint['config_sha256'] ?? '') !== $configsha ||
                ($checkpoint['plan_summary_sha256'] ?? '') !==
                    $bundle['summary_sha256'] ||
                ($checkpoint['batch_id'] ?? '') !==
                    (string)$bundle['summary']['batch_id'] ||
                ($checkpoint['course_key'] ?? '') !== $coursekey ||
                ($checkpoint['source'] ?? '') !== (string)$courseplan['source'] ||
                (int)($checkpoint['source_course_id'] ?? 0) !==
                    (int)$courseplan['source_course_id'] ||
                ($checkpoint['target_shortname'] ?? '') !==
                    (string)$courseplan['target_shortname'] ||
                ($checkpoint['target_fullname'] ?? '') !==
                    (string)$courseplan['target_fullname'] ||
                ($checkpoint['target_category_key'] ?? '') !==
                    (string)$courseplan['target_category_key'] ||
                ($checkpoint['target_course_marker'] ?? '') !==
                    (string)$courseplan['target_course_marker'] ||
                !preg_match(
                    '/^[a-f0-9]{64}$/',
                    (string)($checkpoint['source_state_sha256'] ?? '')
                ) ||
                ($checkpoint['raw_backup_file'] ?? '') !==
                    'backups/raw/' . basename($rawpath) ||
                ($checkpoint['source_inventory_file'] ?? '') !==
                    'course-inventories/' . basename($inventorypath) ||
                ($checkpoint['backup_audit_file'] ?? '') !==
                    'backup-audits/' . basename($auditpath) ||
                ($checkpoint['checkpoint_status'] ?? '') !== 'prepared' ||
                ($checkpoint['destination_write_performed'] ?? null) !== false ||
                $checkpointhashes !== $filehashes) {
            throw new RuntimeException(
                'El checkpoint de ' . $coursekey . ' no coincide con el plan.'
            );
        }
        if (
            array_key_exists('planned_source_users', $checkpoint) &&
            (int)$checkpoint['planned_source_users'] !== $plannedsourceusers
        ) {
            throw new RuntimeException(
                'El checkpoint de ' . $coursekey .
                ' no coincide con sus participantes planeados.'
            );
        }
        if (
            array_key_exists('planned_source_users_verified', $checkpoint) &&
            $checkpoint['planned_source_users_verified'] !== true
        ) {
            throw new RuntimeException(
                'El checkpoint de ' . $coursekey .
                ' no verificó sus participantes planeados.'
            );
        }
        if (
            array_key_exists('zero_participant_course', $checkpoint) &&
            (bool)$checkpoint['zero_participant_course'] !==
                ($plannedsourceusers === 0)
        ) {
            throw new RuntimeException(
                'El checkpoint de ' . $coursekey .
                ' clasifica incorrectamente el curso sin participantes.'
            );
        }
        $rawbytes = filesize($rawpath);
        if ($rawbytes === false || $rawbytes < 1) {
            throw new RuntimeException('El backup de ' . $coursekey . ' está vacío.');
        }
        $checkpointsha = hash_file('sha256', $checkpointpath);
        $entry = [
            'course_key' => $coursekey,
            'source' => (string)$courseplan['source'],
            'source_course_id' => (int)$courseplan['source_course_id'],
            'source_course_idnumber' =>
                (string)$courseplan['source_course_idnumber'],
            'source_shortname' => (string)$courseplan['source_shortname'],
            'target_shortname' => (string)$courseplan['target_shortname'],
            'target_fullname' => (string)$courseplan['target_fullname'],
            'target_category_key' =>
                (string)$courseplan['target_category_key'],
            'target_course_marker' =>
                (string)$courseplan['target_course_marker'],
            'source_state_sha256' =>
                (string)$checkpoint['source_state_sha256'],
            'raw_backup_file' => (string)$checkpoint['raw_backup_file'],
            'raw_backup_sha256' => $filehashes['raw_backup'],
            'raw_backup_bytes' => (int)$rawbytes,
            'source_inventory_file' =>
                (string)$checkpoint['source_inventory_file'],
            'source_inventory_sha256' => $filehashes['source_inventory'],
            'backup_audit_file' => (string)$checkpoint['backup_audit_file'],
            'backup_audit_sha256' => $filehashes['backup_audit'],
            'checkpoint_file' =>
                'backup-checkpoints/' . basename($checkpointpath),
            'checkpoint_sha256' => $checkpointsha,
            'planned_source_users' => $plannedsourceusers,
            'zero_participant_course' => $plannedsourceusers === 0 ? 1 : 0,
            'backup_users' => (int)$checkpoint['backup_users'],
            'mapped_users' => (int)$checkpoint['mapped_users'],
            'reserved_users' => (int)$checkpoint['reserved_users'],
            'approved_identity_merges' =>
                (int)$checkpoint['approved_identity_merges'],
            'question_categories_checked' =>
                (int)$checkpoint['question_categories_checked'],
            'preparation_status' => 'prepared',
        ];
        $entries[] = $entry;
        $progressrows[] = $entry;
        $totalbytes += (int)$rawbytes;
        $totalusers += (int)$checkpoint['backup_users'];
        $totalmappedusers += (int)$checkpoint['mapped_users'];
        $totalreservedusers += (int)$checkpoint['reserved_users'];
        $totalplannedsourceusers += $plannedsourceusers;
        $zeroparticipantcourses += $plannedsourceusers === 0 ? 1 : 0;
        $totalmerges += (int)$checkpoint['approved_identity_merges'];
        $totalquestioncategories +=
            (int)$checkpoint['question_categories_checked'];
    }

    sort($expectedcheckpointnames, SORT_STRING);
    $actualcheckpointnames = array_values(array_map(
        'basename',
        glob($phase6dir . '/backup-checkpoints/checkpoint-*.json') ?: []
    ));
    sort($actualcheckpointnames, SORT_STRING);
    if ($actualcheckpointnames !== $expectedcheckpointnames) {
        throw new RuntimeException(
            'El directorio de checkpoints contiene faltantes o archivos ajenos al plan.'
        );
    }
    if (count($entries) !== (int)$bundle['summary']['courses_to_restore'] ||
            $totalmerges !==
                (int)$bundle['summary']['approved_identity_convergences']) {
        throw new RuntimeException(
            'Los totales preparados no coinciden con el plan aplicable.'
        );
    }

    usort($entries, static fn(array $left, array $right): int =>
        [$left['source'], $left['source_course_id']] <=>
        [$right['source'], $right['source_course_id']]
    );
    $progressrows = $entries;
    $progresspath = $phase6dir . '/backup_progress.csv';
    p5_write_csv($progresspath, [
        'course_key',
        'source',
        'source_course_id',
        'source_course_idnumber',
        'source_shortname',
        'target_shortname',
        'target_fullname',
        'target_category_key',
        'target_course_marker',
        'source_state_sha256',
        'raw_backup_file',
        'raw_backup_sha256',
        'raw_backup_bytes',
        'source_inventory_file',
        'source_inventory_sha256',
        'backup_audit_file',
        'backup_audit_sha256',
        'checkpoint_file',
        'checkpoint_sha256',
        'planned_source_users',
        'zero_participant_course',
        'backup_users',
        'mapped_users',
        'reserved_users',
        'approved_identity_merges',
        'question_categories_checked',
        'preparation_status',
    ], $progressrows);

    $manifest = [
        'schema_version' => '1.0',
        'phase' => '6-multi-course-backup-manifest',
        'generated_at_utc' => gmdate('c'),
        'config_sha256' => $configsha,
        'target_id' => $targetid,
        'batch_id' => (string)$bundle['summary']['batch_id'],
        'plan_summary_sha256' => $bundle['summary_sha256'],
        'plan_artifacts_sha256' => $bundle['hashes'],
        'courses_expected' => (int)$bundle['summary']['courses_to_restore'],
        'courses_prepared' => count($entries),
        'courses_pending' =>
            (int)$bundle['summary']['courses_to_restore'] - count($entries),
        'raw_backups_created' => count($entries),
        'raw_backup_bytes' => $totalbytes,
        'planned_source_user_rows' => $totalplannedsourceusers,
        'zero_participant_courses' => $zeroparticipantcourses,
        'backup_user_rows' => $totalusers,
        'mapped_user_rows' => $totalmappedusers,
        'reserved_user_rows' => $totalreservedusers,
        'approved_identity_convergences' => $totalmerges,
        'question_categories_checked' => $totalquestioncategories,
        'backup_progress_sha256' => hash_file('sha256', $progresspath),
        'entries_sha256' => p6_value_sha256($entries),
        'entries' => $entries,
        'manifest_status' => 'prepared',
        'normalization_performed' => false,
        'destination_write_performed' => false,
        'categories_created' => false,
        'courses_restored' => false,
    ];
    if ($expectlab) {
        $manifest['lab_validation'] =
            count($entries) ===
                (int)$bundle['summary']['courses_to_restore'] &&
            $totalmerges ===
                (int)$bundle['summary']['approved_identity_convergences']
                ? 'passed'
                : 'failed';
        if ($manifest['lab_validation'] !== 'passed') {
            throw new RuntimeException(
                'La preparación LAB no conserva los totales derivados del plan firmado.'
            );
        }
    }
    p5_write_json($phase6dir . '/batch_manifest.json', $manifest);

    cli_writeln(
        'FASE6_BACKUP_MANIFEST_OK courses=' . count($entries) .
        ' pending=0 merges=' . $totalmerges .
        ' write=0'
    );
} catch (Throwable $error) {
    cli_error('FASE6_BACKUP_MANIFEST_ERROR ' . $error->getMessage());
}
