<?php
// Fase 6: adapta un backup sellado de origen al manifiesto central.

declare(strict_types=1);

define('CLI_SCRIPT', true);

require('/var/www/html/config.php');
require_once($CFG->libdir . '/clilib.php');
require_once($CFG->libdir . '/filelib.php');
require_once('/tmp/phase5-lib.php');
require_once('/tmp/phase6-lib.php');

[$options, $unrecognized] = cli_get_params(
    [
        'phase4' => '/exports/phase4',
        'phase6' => '/exports/phase6',
        'package' => null,
        'configsha' => null,
        'targetid' => null,
        'sourceid' => null,
        'coursekey' => null,
        'expectlab' => 0,
        'help' => false,
    ],
    ['h' => 'help']
);
if ($options['help']) {
    cli_writeln(
        "Uso: php phase6-prepare-package-course.php --phase4=DIR " .
        "--phase6=DIR --package=/exports/packages/virtual " .
        "--configsha=SHA256 --targetid=target --sourceid=virtual " .
        "--coursekey=COURSE-VIRTUAL-...\n"
    );
    exit(0);
}
if ($unrecognized) {
    cli_error('Opciones no reconocidas: ' . implode(', ', $unrecognized));
}

try {
    $phase4dir = rtrim((string)$options['phase4'], '/\\');
    $phase6dir = rtrim((string)$options['phase6'], '/\\');
    $packagedir = rtrim((string)$options['package'], '/\\');
    $configsha = p5_require_sha256((string)$options['configsha'], 'configsha');
    $targetid = p5_norm((string)$options['targetid']);
    $sourceid = p5_norm((string)$options['sourceid']);
    $coursekey = strtoupper(trim((string)$options['coursekey']));
    $expectlab = (bool)(int)$options['expectlab'];
    if (!is_dir($packagedir) ||
            !preg_match('/^[a-z][a-z0-9_-]*$/', $targetid) ||
            !preg_match('/^[a-z][a-z0-9_-]*$/', $sourceid) ||
            !preg_match('/^COURSE-[A-Z0-9_-]+-[A-F0-9]{12}$/', $coursekey)) {
        throw new RuntimeException('Los parámetros del curso empaquetado son inválidos.');
    }

    $bundle = p6_load_inventory_plan(
        $phase4dir,
        $phase6dir,
        $configsha,
        $targetid,
        $expectlab
    );
    $courseplan = $bundle['courses_by_key'][$coursekey] ?? null;
    if (!$courseplan ||
            ($courseplan['action'] ?? '') !== 'restore_new' ||
            p5_norm((string)$courseplan['source']) !== $sourceid) {
        throw new RuntimeException(
            'El curso no pertenece al lote restaurable de este origen.'
        );
    }

    $manifestpath = $packagedir . '/manifest.json';
    $manifest = p5_read_json($manifestpath);
    if (($manifest['schema_version'] ?? '') !== '1.0' ||
            ($manifest['package_type'] ?? '') !==
                'moodle-consolidation-source' ||
            ($manifest['source_id'] ?? '') !== $sourceid ||
            ($manifest['package_status'] ?? '') !== 'sealed') {
        throw new RuntimeException(
            'El manifiesto del paquete de origen no es válido.'
        );
    }
    $packageentry = null;
    foreach ($manifest['entries'] ?? [] as $candidate) {
        if (($candidate['course_key'] ?? '') === $coursekey) {
            $packageentry = $candidate;
            break;
        }
    }
    if (!is_array($packageentry) ||
            (int)($packageentry['source_course_id'] ?? 0) !==
                (int)$courseplan['source_course_id']) {
        throw new RuntimeException(
            'El paquete no contiene el curso exacto aprobado por el plan.'
        );
    }
    $packagebackuppath = $packagedir . '/' .
        ltrim((string)$packageentry['backup_file'], '/\\');
    $packageinventorypath = $packagedir . '/' .
        ltrim((string)$packageentry['inventory_file'], '/\\');
    if (!is_readable($packagebackuppath) ||
            !is_readable($packageinventorypath) ||
            filesize($packagebackuppath) < 1 ||
            filesize($packageinventorypath) < 1) {
        throw new RuntimeException(
            'El backup o inventario sellado no está disponible.'
        );
    }
    $packagemanifestsha = hash_file('sha256', $manifestpath);
    $packagebackupsha = (string)$packageentry['backup_sha256'];
    $packagedocument = p5_read_json($packageinventorypath);
    $inventory = $packagedocument['inventory'] ?? null;
    if (($packagedocument['schema_version'] ?? '') !== '1.0' ||
            ($packagedocument['package_type'] ?? '') !==
                'moodle-consolidation-course-inventory' ||
            ($packagedocument['source_id'] ?? '') !== $sourceid ||
            ($packagedocument['course_key'] ?? '') !== $coursekey ||
            ($packagedocument['write_performed'] ?? null) !== false ||
            !is_array($inventory)) {
        throw new RuntimeException(
            'El inventario detallado recibido no conserva su contrato.'
        );
    }
    $sourcestatehash =
        (string)($packagedocument['source_state_sha256'] ?? '');
    if (!preg_match('/^[a-f0-9]{64}$/', $sourcestatehash)) {
        throw new RuntimeException('El inventario no contiene source_state_sha256.');
    }

    $expectedcourse = null;
    foreach (
        $bundle['source_inventories'][$sourceid]['courses'] ?? []
        as $candidate
    ) {
        if ((int)($candidate['source_course_id'] ?? 0) ===
                (int)$courseplan['source_course_id']) {
            $expectedcourse = $candidate;
            break;
        }
    }
    $detailcourse = $inventory['course'] ?? [];
    if (!is_array($expectedcourse) ||
            (int)($detailcourse['source_course_id'] ?? 0) !==
                (int)$expectedcourse['source_course_id'] ||
            (int)($detailcourse['category_id'] ?? 0) !==
                (int)$expectedcourse['source_category_id'] ||
            (string)($detailcourse['fullname'] ?? '') !==
                (string)$expectedcourse['fullname'] ||
            (string)($detailcourse['shortname'] ?? '') !==
                (string)$expectedcourse['shortname'] ||
            (string)($detailcourse['idnumber'] ?? '') !==
                (string)$expectedcourse['idnumber']) {
        throw new RuntimeException(
            'El inventario detallado no coincide con el inventario global.'
        );
    }
    $expectedmodules = $expectedcourse['modules_by_type'] ?? [];
    $actualmodules = $inventory['modules_by_type'] ?? [];
    ksort($expectedmodules, SORT_STRING);
    ksort($actualmodules, SORT_STRING);
    if ($expectedmodules !== $actualmodules ||
            count($expectedcourse['enrolments'] ?? []) !==
                count($inventory['enrolments'] ?? []) ||
            count($expectedcourse['roles'] ?? []) !==
                count($inventory['roles'] ?? [])) {
        throw new RuntimeException(
            'El detalle académico no coincide con el inventario sellado.'
        );
    }

    $basename = p6_backup_basename($coursekey);
    $rawdir = $phase6dir . '/backups/raw';
    $inventorydir = $phase6dir . '/course-inventories';
    $auditdir = $phase6dir . '/backup-audits';
    $checkpointdir = $phase6dir . '/backup-checkpoints';
    foreach ([$rawdir, $inventorydir, $auditdir, $checkpointdir] as $directory) {
        if (!is_dir($directory) &&
                !mkdir($directory, 0770, true) &&
                !is_dir($directory)) {
            throw new RuntimeException('No fue posible crear ' . $directory . '.');
        }
    }
    $rawpath = $rawdir . '/raw-' . $basename . '.mbz';
    $inventorypath =
        $inventorydir . '/inventory-' . $basename . '.json';
    $auditpath = $auditdir . '/audit-' . $basename . '.json';
    $checkpointpath =
        $checkpointdir . '/checkpoint-' . $basename . '.json';
    $plannedsourceusers = count(
        p6_expected_course_source_user_ids($bundle, $coursekey)
    );

    if (is_readable($checkpointpath)) {
        $checkpoint = p5_read_json($checkpointpath);
        $files = [
            'raw_backup' => $rawpath,
            'source_inventory' => $inventorypath,
            'backup_audit' => $auditpath,
        ];
        $actualhashes = p5_hash_files($files);
        $checkpointfiles = $checkpoint['files_sha256'] ?? [];
        if (!is_array($checkpointfiles)) {
            throw new RuntimeException('El checkpoint existente no contiene hashes.');
        }
        ksort($checkpointfiles, SORT_STRING);
        if (($checkpoint['schema_version'] ?? '') !== '1.0' ||
                ($checkpoint['phase'] ?? '') !==
                    '6-course-backup-checkpoint' ||
                ($checkpoint['config_sha256'] ?? '') !== $configsha ||
                ($checkpoint['plan_summary_sha256'] ?? '') !==
                    $bundle['summary_sha256'] ||
                ($checkpoint['course_key'] ?? '') !== $coursekey ||
                ($checkpoint['source'] ?? '') !== $sourceid ||
                (int)($checkpoint['source_course_id'] ?? 0) !==
                    (int)$courseplan['source_course_id'] ||
                ($checkpoint['source_state_sha256'] ?? '') !==
                    $sourcestatehash ||
                ($checkpoint['source_package_manifest_sha256'] ?? '') !==
                    $packagemanifestsha ||
                ($checkpoint['source_package_backup_sha256'] ?? '') !==
                    $packagebackupsha ||
                ($checkpoint['checkpoint_status'] ?? '') !== 'prepared' ||
                $checkpointfiles !== $actualhashes) {
            throw new RuntimeException(
                'El checkpoint central perdió integridad o corresponde a otro plan.'
            );
        }
        cli_writeln(
            'FASE6_PACKAGE_BACKUP_OK course_key=' . $coursekey .
            ' source=' . $sourceid .
            ' status=reused users=' . (int)$checkpoint['backup_users']
        );
        exit(0);
    }
    if (is_file($rawpath) || is_file($inventorypath) || is_file($auditpath)) {
        throw new RuntimeException(
            'Existen artefactos centrales parciales sin checkpoint.'
        );
    }

    $inventorydocument = [
        'schema_version' => '1.0',
        'phase' => '6-source-course-backup-inventory',
        'generated_at_utc' => gmdate('c'),
        'config_sha256' => $configsha,
        'plan_summary_sha256' => $bundle['summary_sha256'],
        'batch_id' => (string)$bundle['summary']['batch_id'],
        'course_key' => $coursekey,
        'source_id' => $sourceid,
        'source_state_sha256' => $sourcestatehash,
        'source_package_manifest_sha256' =>
            $packagemanifestsha,
        'source_package_backup_sha256' =>
            $packagebackupsha,
        'inventory' => $inventory,
        'write_performed' => false,
    ];
    p5_write_json($inventorypath, $inventorydocument);
    try {
        if (!copy($packagebackuppath, $rawpath)) {
            throw new RuntimeException(
                'No fue posible copiar el backup sellado recibido.'
            );
        }
        $inspection = p6_inspect_raw_backup(
            $rawpath,
            $sourceid,
            $coursekey,
            $bundle
        );
        if ((int)$inspection['planned_source_users'] !==
                $plannedsourceusers ||
                $inspection['planned_source_users_verified'] !== true) {
            throw new RuntimeException(
                'El backup no contiene exactamente los participantes planeados.'
            );
        }
        $auditdocument = [
            'schema_version' => '1.0',
            'phase' => '6-raw-backup-audit',
            'generated_at_utc' => gmdate('c'),
            'config_sha256' => $configsha,
            'plan_summary_sha256' => $bundle['summary_sha256'],
            'batch_id' => (string)$bundle['summary']['batch_id'],
            'course_key' => $coursekey,
            'source_id' => $sourceid,
            'source_course_id' => (int)$courseplan['source_course_id'],
            'target_course_marker' =>
                (string)$courseplan['target_course_marker'],
            'planned_source_users' =>
                (int)$inspection['planned_source_users'],
            'planned_source_users_verified' =>
                (bool)$inspection['planned_source_users_verified'],
            'zero_participant_course' =>
                (bool)$inspection['zero_participant_course'],
            'backup_users' => (int)$inspection['backup_users'],
            'mapped_users' => (int)$inspection['mapped_users'],
            'reserved_users' => (int)$inspection['reserved_users'],
            'approved_identity_merges' =>
                (int)$inspection['approved_identity_merges'],
            'question_categories_checked' =>
                (int)$inspection['question_categories_checked'],
            'question_categories_with_questions' =>
                (int)$inspection['question_categories_with_questions'],
            'user_mapping_audit' => $inspection['audit_rows'],
            'raw_backup_sha256' => hash_file('sha256', $rawpath),
            'normalization_performed' => false,
            'destination_write_performed' => false,
        ];
        p5_write_json($auditpath, $auditdocument);

        $files = [
            'raw_backup' => $rawpath,
            'source_inventory' => $inventorypath,
            'backup_audit' => $auditpath,
        ];
        $checkpoint = [
            'schema_version' => '1.0',
            'phase' => '6-course-backup-checkpoint',
            'generated_at_utc' => gmdate('c'),
            'config_sha256' => $configsha,
            'plan_summary_sha256' => $bundle['summary_sha256'],
            'batch_id' => (string)$bundle['summary']['batch_id'],
            'course_key' => $coursekey,
            'source' => $sourceid,
            'source_course_id' => (int)$courseplan['source_course_id'],
            'source_course_idnumber' =>
                (string)$courseplan['source_course_idnumber'],
            'source_shortname' =>
                (string)$courseplan['source_shortname'],
            'target_shortname' =>
                (string)$courseplan['target_shortname'],
            'target_fullname' =>
                (string)$courseplan['target_fullname'],
            'target_category_key' =>
                (string)$courseplan['target_category_key'],
            'target_course_marker' =>
                (string)$courseplan['target_course_marker'],
            'source_state_sha256' => $sourcestatehash,
            'source_package_manifest_sha256' => $packagemanifestsha,
            'source_package_backup_sha256' => $packagebackupsha,
            'raw_backup_file' => 'backups/raw/' . basename($rawpath),
            'source_inventory_file' =>
                'course-inventories/' . basename($inventorypath),
            'backup_audit_file' =>
                'backup-audits/' . basename($auditpath),
            'files_sha256' => p5_hash_files($files),
            'planned_source_users' =>
                (int)$inspection['planned_source_users'],
            'planned_source_users_verified' =>
                (bool)$inspection['planned_source_users_verified'],
            'zero_participant_course' =>
                (bool)$inspection['zero_participant_course'],
            'backup_users' => (int)$inspection['backup_users'],
            'mapped_users' => (int)$inspection['mapped_users'],
            'reserved_users' => (int)$inspection['reserved_users'],
            'approved_identity_merges' =>
                (int)$inspection['approved_identity_merges'],
            'question_categories_checked' =>
                (int)$inspection['question_categories_checked'],
            'question_categories_with_questions' =>
                (int)$inspection['question_categories_with_questions'],
            'checkpoint_status' => 'prepared',
            'destination_write_performed' => false,
        ];
        p5_write_json($checkpointpath, $checkpoint);
    } catch (Throwable $error) {
        foreach ([$rawpath, $inventorypath, $auditpath] as $partialpath) {
            if (is_file($partialpath)) {
                @unlink($partialpath);
            }
        }
        throw $error;
    }

    cli_writeln(
        'FASE6_PACKAGE_BACKUP_OK course_key=' . $coursekey .
        ' source=' . $sourceid .
        ' status=created users=' . (int)$inspection['backup_users'] .
        ' planned=' . (int)$inspection['planned_source_users'] .
        ' merges=' . (int)$inspection['approved_identity_merges']
    );
} catch (Throwable $error) {
    cli_error('FASE6_PACKAGE_BACKUP_ERROR ' . $error->getMessage());
}
