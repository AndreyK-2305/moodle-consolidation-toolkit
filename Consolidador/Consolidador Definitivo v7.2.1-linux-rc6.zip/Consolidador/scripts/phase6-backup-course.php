<?php
// Fase 6: prepara un backup crudo, íntegro y reanudable para un curso del lote.

declare(strict_types=1);

define('CLI_SCRIPT', true);

require('/var/www/html/config.php');
require_once($CFG->libdir . '/clilib.php');
require_once($CFG->libdir . '/filelib.php');
require_once('/tmp/phase5-lib.php');
require_once('/tmp/phase6-lib.php');

[$options, $unrecognized] = cli_get_params(
    [
        'phase4' => '/exports/phase4',
        'phase6' => '/exports/phase6',
        'configsha' => null,
        'targetid' => null,
        'sourceid' => null,
        'coursekey' => null,
        'expectlab' => 0,
        'help' => false,
    ],
    ['h' => 'help']
);
if ($options['help']) {
    cli_writeln(
        "Uso: php phase6-backup-course.php --phase4=/exports/phase4 " .
        "--phase6=/exports/phase6 --configsha=SHA256 --targetid=target " .
        "--sourceid=virtual --coursekey=COURSE-VIRTUAL-... [--expectlab=1]\n"
    );
    exit(0);
}
if ($unrecognized) {
    cli_error('Opciones no reconocidas: ' . implode(', ', $unrecognized));
}

try {
    $phase4dir = rtrim((string)$options['phase4'], '/\\');
    $phase6dir = rtrim((string)$options['phase6'], '/\\');
    $configsha = p5_require_sha256((string)$options['configsha'], 'configsha');
    $targetid = p5_norm((string)$options['targetid']);
    $sourceid = p5_norm((string)$options['sourceid']);
    $coursekey = trim((string)$options['coursekey']);
    $expectlab = (bool)(int)$options['expectlab'];
    if (!preg_match('/^[a-z][a-z0-9_-]*$/', $targetid) ||
            !preg_match('/^[a-z][a-z0-9_-]*$/', $sourceid) ||
            !preg_match('/^COURSE-[A-Z0-9_-]+-[A-F0-9]{12}$/', $coursekey)) {
        throw new RuntimeException('Los parámetros del curso son inválidos.');
    }

    $bundle = p6_load_inventory_plan(
        $phase4dir,
        $phase6dir,
        $configsha,
        $targetid,
        $expectlab
    );
    $courseplan = $bundle['courses_by_key'][$coursekey] ?? null;
    if (!$courseplan ||
            ($courseplan['action'] ?? '') !== 'restore_new' ||
            p5_norm((string)$courseplan['source']) !== $sourceid) {
        throw new RuntimeException(
            'El curso no pertenece al lote restaurable de este origen.'
        );
    }

    $sourceinventory = $bundle['source_inventories'][$sourceid] ?? null;
    $expectedcourse = null;
    foreach ($sourceinventory['courses'] ?? [] as $candidate) {
        if ((int)($candidate['source_course_id'] ?? 0) ===
                (int)$courseplan['source_course_id']) {
            $expectedcourse = $candidate;
            break;
        }
    }
    if (!$expectedcourse) {
        throw new RuntimeException('El inventario firmado ya no contiene el curso.');
    }

    $courseid = (int)$courseplan['source_course_id'];
    $course = $DB->get_record(
        'course',
        ['id' => $courseid],
        'id,category,fullname,shortname,idnumber,visible,startdate,enddate,format,enablecompletion',
        MUST_EXIST
    );
    $metadatafields = [
        'source_course_id' => (int)$course->id,
        'source_category_id' => (int)$course->category,
        'fullname' => (string)$course->fullname,
        'shortname' => (string)$course->shortname,
        'idnumber' => (string)$course->idnumber,
        'visible' => (int)$course->visible,
        'startdate' => (int)$course->startdate,
        'enddate' => (int)$course->enddate,
        'format' => (string)$course->format,
        'enablecompletion' => (int)$course->enablecompletion,
    ];
    foreach ($metadatafields as $field => $actual) {
        if (!array_key_exists($field, $expectedcourse) ||
                (string)$expectedcourse[$field] !== (string)$actual) {
            throw new RuntimeException(
                'El curso cambió después del comando 19 en ' . $field . '.'
            );
        }
    }

    $inventory = p5_collect_course_inventory($courseid);
    $expectedmodules = $expectedcourse['modules_by_type'] ?? [];
    $actualmodules = $inventory['modules_by_type'] ?? [];
    ksort($expectedmodules, SORT_STRING);
    ksort($actualmodules, SORT_STRING);
    if ($expectedmodules !== $actualmodules ||
            count($expectedcourse['enrolments'] ?? []) !==
                (int)$inventory['counts']['enrolments'] ||
            count($expectedcourse['roles'] ?? []) !==
                (int)$inventory['counts']['course_role_assignments']) {
        throw new RuntimeException(
            'El inventario académico básico cambió después del comando 19.'
        );
    }
    $sourcestatehash = p6_value_sha256($inventory);

    $basename = p6_backup_basename($coursekey);
    $rawdir = $phase6dir . '/backups/raw';
    $inventorydir = $phase6dir . '/course-inventories';
    $auditdir = $phase6dir . '/backup-audits';
    $checkpointdir = $phase6dir . '/backup-checkpoints';
    foreach ([$rawdir, $inventorydir, $auditdir, $checkpointdir] as $directory) {
        if (!is_dir($directory) &&
                !mkdir($directory, 0770, true) &&
                !is_dir($directory)) {
            throw new RuntimeException('No fue posible crear ' . $directory . '.');
        }
    }
    $rawpath = $rawdir . '/raw-' . $basename . '.mbz';
    $inventorypath = $inventorydir . '/inventory-' . $basename . '.json';
    $auditpath = $auditdir . '/audit-' . $basename . '.json';
    $checkpointpath = $checkpointdir . '/checkpoint-' . $basename . '.json';
    $plannedsourceusers = count(
        p6_expected_course_source_user_ids($bundle, $coursekey)
    );

    if (is_readable($checkpointpath)) {
        $checkpoint = p5_read_json($checkpointpath);
        $files = [
            'raw_backup' => $rawpath,
            'source_inventory' => $inventorypath,
            'backup_audit' => $auditpath,
        ];
        $actualhashes = p5_hash_files($files);
        $checkpointfiles = $checkpoint['files_sha256'] ?? [];
        if (!is_array($checkpointfiles)) {
            throw new RuntimeException('El checkpoint existente no contiene hashes.');
        }
        ksort($checkpointfiles, SORT_STRING);
        if (($checkpoint['schema_version'] ?? '') !== '1.0' ||
                ($checkpoint['phase'] ?? '') !== '6-course-backup-checkpoint' ||
                ($checkpoint['plan_summary_sha256'] ?? '') !==
                    $bundle['summary_sha256'] ||
                ($checkpoint['course_key'] ?? '') !== $coursekey ||
                ($checkpoint['source'] ?? '') !== $sourceid ||
                (int)($checkpoint['source_course_id'] ?? 0) !== $courseid ||
                ($checkpoint['source_state_sha256'] ?? '') !== $sourcestatehash ||
                ($checkpoint['raw_backup_file'] ?? '') !==
                    'backups/raw/' . basename($rawpath) ||
                ($checkpoint['source_inventory_file'] ?? '') !==
                    'course-inventories/' . basename($inventorypath) ||
                ($checkpoint['backup_audit_file'] ?? '') !==
                    'backup-audits/' . basename($auditpath) ||
                ($checkpoint['checkpoint_status'] ?? '') !== 'prepared' ||
                $checkpointfiles !== $actualhashes) {
            throw new RuntimeException(
                'El checkpoint existente cambió o el curso fue modificado; ' .
                'no se reemplazará automáticamente.'
            );
        }
        $reinspection = p6_inspect_raw_backup(
            $rawpath,
            $sourceid,
            $coursekey,
            $bundle
        );
        foreach ([
            'backup_users',
            'mapped_users',
            'reserved_users',
            'approved_identity_merges',
            'question_categories_checked',
            'question_categories_with_questions',
        ] as $metric) {
            if ((int)($checkpoint[$metric] ?? -1) !==
                    (int)$reinspection[$metric]) {
                throw new RuntimeException(
                    'El checkpoint existente no coincide con la nueva auditoría en ' .
                    $metric . '.'
                );
            }
        }
        if ((int)$reinspection['planned_source_users'] !==
                $plannedsourceusers ||
                $reinspection['planned_source_users_verified'] !== true) {
            throw new RuntimeException(
                'La nueva auditoría no confirmó todos los participantes planeados.'
            );
        }
        cli_writeln(
            'FASE6_BACKUP_OK course_key=' . $coursekey .
            ' source=' . $sourceid .
            ' status=reused users=' . (int)$checkpoint['backup_users'] .
            ' planned=' . $plannedsourceusers .
            ' merges=' . (int)$checkpoint['approved_identity_merges']
        );
        exit(0);
    }

    if (is_file($rawpath) || is_file($inventorypath) || is_file($auditpath)) {
        throw new RuntimeException(
            'Existen artefactos parciales sin checkpoint; requieren revisión antes de continuar.'
        );
    }

    $inventorydocument = [
        'schema_version' => '1.0',
        'phase' => '6-source-course-backup-inventory',
        'generated_at_utc' => gmdate('c'),
        'config_sha256' => $configsha,
        'plan_summary_sha256' => $bundle['summary_sha256'],
        'batch_id' => (string)$bundle['summary']['batch_id'],
        'course_key' => $coursekey,
        'source_id' => $sourceid,
        'source_state_sha256' => $sourcestatehash,
        'inventory' => $inventory,
        'write_performed' => false,
    ];
    p5_write_json($inventorypath, $inventorydocument);
    try {
        p5_create_course_backup($courseid, $rawpath);
        $inspection = p6_inspect_raw_backup(
            $rawpath,
            $sourceid,
            $coursekey,
            $bundle
        );
        $auditdocument = [
            'schema_version' => '1.0',
            'phase' => '6-raw-backup-audit',
            'generated_at_utc' => gmdate('c'),
            'config_sha256' => $configsha,
            'plan_summary_sha256' => $bundle['summary_sha256'],
            'batch_id' => (string)$bundle['summary']['batch_id'],
            'course_key' => $coursekey,
            'source_id' => $sourceid,
            'source_course_id' => $courseid,
            'target_course_marker' => (string)$courseplan['target_course_marker'],
            'planned_source_users' =>
                (int)$inspection['planned_source_users'],
            'planned_source_users_verified' =>
                (bool)$inspection['planned_source_users_verified'],
            'zero_participant_course' =>
                (bool)$inspection['zero_participant_course'],
            'backup_users' => (int)$inspection['backup_users'],
            'mapped_users' => (int)$inspection['mapped_users'],
            'reserved_users' => (int)$inspection['reserved_users'],
            'approved_identity_merges' =>
                (int)$inspection['approved_identity_merges'],
            'question_categories_checked' =>
                (int)$inspection['question_categories_checked'],
            'question_categories_with_questions' =>
                (int)$inspection['question_categories_with_questions'],
            'user_mapping_audit' => $inspection['audit_rows'],
            'raw_backup_sha256' => hash_file('sha256', $rawpath),
            'normalization_performed' => false,
            'destination_write_performed' => false,
        ];
        p5_write_json($auditpath, $auditdocument);

        $files = [
            'raw_backup' => $rawpath,
            'source_inventory' => $inventorypath,
            'backup_audit' => $auditpath,
        ];
        $checkpoint = [
            'schema_version' => '1.0',
            'phase' => '6-course-backup-checkpoint',
            'generated_at_utc' => gmdate('c'),
            'config_sha256' => $configsha,
            'plan_summary_sha256' => $bundle['summary_sha256'],
            'batch_id' => (string)$bundle['summary']['batch_id'],
            'course_key' => $coursekey,
            'source' => $sourceid,
            'source_course_id' => $courseid,
            'source_course_idnumber' =>
                (string)$courseplan['source_course_idnumber'],
            'source_shortname' => (string)$courseplan['source_shortname'],
            'target_shortname' => (string)$courseplan['target_shortname'],
            'target_fullname' => (string)$courseplan['target_fullname'],
            'target_category_key' => (string)$courseplan['target_category_key'],
            'target_course_marker' => (string)$courseplan['target_course_marker'],
            'source_state_sha256' => $sourcestatehash,
            'raw_backup_file' => 'backups/raw/' . basename($rawpath),
            'source_inventory_file' =>
                'course-inventories/' . basename($inventorypath),
            'backup_audit_file' => 'backup-audits/' . basename($auditpath),
            'files_sha256' => p5_hash_files($files),
            'planned_source_users' =>
                (int)$inspection['planned_source_users'],
            'planned_source_users_verified' =>
                (bool)$inspection['planned_source_users_verified'],
            'zero_participant_course' =>
                (bool)$inspection['zero_participant_course'],
            'backup_users' => (int)$inspection['backup_users'],
            'mapped_users' => (int)$inspection['mapped_users'],
            'reserved_users' => (int)$inspection['reserved_users'],
            'approved_identity_merges' =>
                (int)$inspection['approved_identity_merges'],
            'question_categories_checked' =>
                (int)$inspection['question_categories_checked'],
            'question_categories_with_questions' =>
                (int)$inspection['question_categories_with_questions'],
            'checkpoint_status' => 'prepared',
            'destination_write_performed' => false,
        ];
        p5_write_json($checkpointpath, $checkpoint);
    } catch (Throwable $error) {
        foreach ([$rawpath, $inventorypath, $auditpath] as $partialpath) {
            if (is_file($partialpath)) {
                @unlink($partialpath);
            }
        }
        throw $error;
    }

    cli_writeln(
        'FASE6_BACKUP_OK course_key=' . $coursekey .
        ' source=' . $sourceid .
        ' status=created users=' . (int)$inspection['backup_users'] .
        ' planned=' . (int)$inspection['planned_source_users'] .
        ' merges=' . (int)$inspection['approved_identity_merges']
    );
} catch (Throwable $error) {
    cli_error('FASE6_BACKUP_ERROR ' . $error->getMessage());
}
