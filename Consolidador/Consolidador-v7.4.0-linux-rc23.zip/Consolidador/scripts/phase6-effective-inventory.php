<?php
// Vista efectiva y transportable de inventario para Fase 6.

declare(strict_types=1);

defined('MOODLE_INTERNAL') || die();

function p6_relation_candidate_matches(array $row, array $candidate): bool {
    foreach ($row as $field => $value) {
        if ($field === 'activity_key' || $field === '_source_module_id') {
            continue;
        }
        if (!array_key_exists($field, $candidate) ||
                p5_relation_canonical_value($field, $candidate[$field]) !==
                    p5_relation_canonical_value($field, $value)) {
            return false;
        }
    }
    return true;
}

function p6_effective_relation_activity_keys(
    array $rows,
    string $relation,
    array $modulesbysourceid,
    array $primaryidsbykey,
    array $nameidsbykey,
    array $structuralcandidates,
    array &$evidence
): array {
    $resolved = [];
    foreach ($rows as $index => $row) {
        if (!is_array($row)) {
            throw new RuntimeException(
                'MODULE_RELATION_SCHEMA_INVALID ' . $relation .
                ' contiene una fila no interpretable.'
            );
        }
        $legacykey = (string)($row['activity_key'] ?? '');
        $moduleids = array_values(array_unique(array_map(
            'intval',
            $primaryidsbykey[$legacykey] ?? []
        )));
        $mode = 'primary_legacy_key';
        if (count($moduleids) !== 1) {
            $moduleids = array_values(array_unique(array_map(
                'intval',
                $nameidsbykey[$legacykey] ?? []
            )));
            $mode = 'historical_name_alias';
        }
        if (count($moduleids) !== 1) {
            $prefix = explode('|', $legacykey, 2)[0] ?? '';
            $structuralids = [];
            foreach ($structuralcandidates as $candidate) {
                $sourcemoduleid = (int)($candidate['_source_module_id'] ?? 0);
                $module = $modulesbysourceid[$sourcemoduleid] ?? null;
                if (!$module || p5_norm((string)$module['modname']) !== p5_norm($prefix) ||
                        !p6_relation_candidate_matches($row, $candidate)) {
                    continue;
                }
                $structuralids[$sourcemoduleid] = true;
            }
            $moduleids = array_map('intval', array_keys($structuralids));
            sort($moduleids, SORT_NUMERIC);
            $mode = 'structural_fallback';
        }
        if (count($moduleids) !== 1 || !isset($modulesbysourceid[$moduleids[0]])) {
            $evidence['aliases_blocked']++;
            $evidence['blocked'][] = [
                'relation' => $relation,
                'row_index' => $index,
                'activity_key' => $legacykey,
                'source_module_id_candidates' => $moduleids,
            ];
            throw new RuntimeException(
                'MODULE_ACTIVITY_ALIAS_UNRESOLVED relation=' . $relation .
                ' activity_key=' . $legacykey .
                ' candidates=' . implode('|', $moduleids) . '.'
            );
        }
        $sourcemoduleid = $moduleids[0];
        $row['activity_key'] =
            (string)$modulesbysourceid[$sourcemoduleid]['module_key'];
        $resolved[] = $row;
        $evidence[$mode]++;
        $evidence['resolutions'][] = [
            'relation' => $relation,
            'row_index' => $index,
            'legacy_activity_key' => $legacykey,
            'effective_activity_key' => $row['activity_key'],
            'source_module_id' => $sourcemoduleid,
            'resolution_mode' => $mode,
        ];
    }
    return $resolved;
}

function p6_validate_transportable_file_payloads(
    string $backupdirectory,
    array $candidatefiles
): int {
    if (!$candidatefiles) {
        return 0;
    }
    $filespath = rtrim($backupdirectory, '/\\') . '/files.xml';
    if (!is_readable($filespath)) {
        throw new RuntimeException('MODULE_FILE_TRANSPORT_INVALID files.xml ausente.');
    }
    $dom = new DOMDocument();
    $dom->preserveWhiteSpace = false;
    if (!$dom->load($filespath, LIBXML_NONET)) {
        throw new RuntimeException('MODULE_FILE_TRANSPORT_INVALID files.xml no es válido.');
    }
    $needed = [];
    foreach ($candidatefiles as $row) {
        $fileid = (int)($row['_file_id'] ?? 0);
        if ($fileid < 1) {
            throw new RuntimeException('MODULE_FILE_TRANSPORT_INVALID file_id ausente.');
        }
        $needed[$fileid] = true;
    }
    $checked = 0;
    $xpath = new DOMXPath($dom);
    foreach ($xpath->query('//*[local-name()="file"]') ?: [] as $node) {
        if (!$node instanceof DOMElement) {
            continue;
        }
        $fileid = (int)$node->getAttribute('id');
        if (!isset($needed[$fileid])) {
            continue;
        }
        unset($needed[$fileid]);
        $filename = (string)(p5_dom_direct_text($node, 'filename') ?? '');
        if ($filename === '.') {
            continue;
        }
        $filesizetext = p5_dom_direct_text($node, 'filesize');
        if ($filesizetext === null || !preg_match('/^[0-9]+$/', $filesizetext)) {
            throw new RuntimeException(
                'MODULE_FILE_PAYLOAD_METADATA_MISSING file_id=' . $fileid . '.'
            );
        }
        $filesize = (int)$filesizetext;
        $contenthash = (string)(p5_dom_direct_text($node, 'contenthash') ?? '');
        if (!preg_match('/^[a-f0-9]{40}$/', $contenthash)) {
            throw new RuntimeException(
                'MODULE_FILE_PAYLOAD_METADATA_MISSING file_id=' . $fileid . '.'
            );
        }
        $payload = rtrim($backupdirectory, '/\\') . '/files/' .
            substr($contenthash, 0, 2) . '/' . $contenthash;
        $actualsize = is_file($payload) ? filesize($payload) : false;
        if ($actualsize === false || (int)$actualsize !== $filesize ||
                hash_file('sha1', $payload) !== $contenthash) {
            throw new RuntimeException(
                'MODULE_FILE_PAYLOAD_MISSING file_id=' . $fileid .
                ' contenthash=' . $contenthash . '.'
            );
        }
        $checked++;
    }
    if ($needed) {
        throw new RuntimeException(
            'MODULE_FILE_TRANSPORT_INVALID missing_file_ids=' .
            implode('|', array_keys($needed)) . '.'
        );
    }
    return $checked;
}

/**
 * Construye la vista efectiva de Fase 6 sin reemplazar poblaciones académicas
 * por el MBZ. Solo relations.files usa files.xml como verdad de transporte.
 */
function p6_effective_restore_inventory(
    array $inventory,
    string $sourceid,
    int $sourcecourseid,
    string $backupdirectory,
    ?array &$audit = null
): array {
    $filespath = rtrim($backupdirectory, '/\\') . '/files.xml';
    if (!is_readable($filespath)) {
        throw new RuntimeException(
            'MODULE_FILE_TRANSPORT_INVALID files.xml ausente.'
        );
    }
    $identityplan = p5_prepare_module_identities(
        $inventory,
        $sourceid,
        $sourcecourseid
    );
    $contextevidence = null;
    $activitydirectories = p5_rewrite_backup_module_idnumbers(
        $backupdirectory,
        $identityplan['modules_by_source_id'],
        $contextevidence
    );
    $fileevidence = null;
    $candidates = p5_backup_relation_candidates(
        $backupdirectory,
        $activitydirectories,
        $fileevidence
    );
    $prepared = $identityplan['inventory'];
    $modulesbysourceid = $identityplan['modules_by_source_id'];
    $primaryidsbykey = $identityplan['legacy_module_ids_by_key'];
    $nameidsbykey = [];
    foreach ($modulesbysourceid as $sourcemoduleid => $module) {
        $effectivekey = (string)$module['module_key'];
        $primaryidsbykey[$effectivekey][] = (int)$sourcemoduleid;
        $namekey = p5_module_key(
            (string)$module['modname'],
            '',
            (string)$module['name']
        );
        $nameidsbykey[$namekey][] = (int)$sourcemoduleid;
    }
    $aliasevidence = [
        'primary_legacy_key' => 0,
        'historical_name_alias' => 0,
        'structural_fallback' => 0,
        'aliases_blocked' => 0,
        'resolutions' => [],
        'blocked' => [],
    ];
    foreach ($prepared['relations'] ?? [] as $relation => $rows) {
        if (!is_array($rows) || $relation === 'course_completions' ||
                $relation === 'files') {
            continue;
        }
        $prepared['relations'][$relation] = p6_effective_relation_activity_keys(
            $rows,
            (string)$relation,
            $modulesbysourceid,
            $primaryidsbykey,
            $nameidsbykey,
            $candidates[$relation] ?? [],
            $aliasevidence
        );
    }

    $sourcefiles = is_array($inventory['relations']['files'] ?? null)
        ? $inventory['relations']['files']
        : [];
    $transportfiles = p5_filter_comparable_files($candidates['files'] ?? []);
    $payloadschecked = p6_validate_transportable_file_payloads(
        $backupdirectory,
        $transportfiles
    );
    $projectedfiles = [];
    foreach ($transportfiles as $candidate) {
        $sourcemoduleid = (int)($candidate['_source_module_id'] ?? 0);
        if (!isset($modulesbysourceid[$sourcemoduleid])) {
            throw new RuntimeException(
                'MODULE_FILE_CONTEXT_UNRESOLVED source_module_id=' .
                $sourcemoduleid . '.'
            );
        }
        $projectedfiles[] = [
            'source_user_id' => (int)($candidate['source_user_id'] ?? 0),
            'activity_key' =>
                (string)$modulesbysourceid[$sourcemoduleid]['module_key'],
            'component' => (string)$candidate['component'],
            'filearea' => (string)$candidate['filearea'],
            'filename' => (string)$candidate['filename'],
        ];
    }
    usort($projectedfiles, static fn(array $left, array $right): int => strcmp(
        json_encode($left, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        json_encode($right, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
    ));
    $prepared['relations']['files'] = $projectedfiles;
    if (isset($prepared['counts']['module_files'])) {
        $prepared['counts']['module_files'] = count($projectedfiles);
    }
    $sourcecomparable = p5_filter_comparable_files($sourcefiles);
    $fileaudit = $fileevidence ?? [];
    $fileaudit['files_source_database_rows'] = count($sourcefiles);
    $fileaudit['files_source_database_comparable_rows'] = count($sourcecomparable);
    $fileaudit['files_xml_transport_rows'] = count($candidates['files'] ?? []);
    $fileaudit['files_comparable_rows'] = count($projectedfiles);
    $fileaudit['files_regenerable_excluded_source'] =
        count($sourcefiles) - count($sourcecomparable);
    $fileaudit['files_regenerable_excluded_transport'] =
        count($candidates['files'] ?? []) - count($transportfiles);
    $fileaudit['files_payloads_checked'] = $payloadschecked;
    $fileaudit['transport_projection_applied'] = true;

    $audit = [
        'module_identity' => $identityplan['metrics'] + [
            'module_contexts' => $contextevidence,
        ],
        'activity_aliases' => $aliasevidence,
        'files_transport' => $fileaudit,
    ];
    return $prepared;
}
