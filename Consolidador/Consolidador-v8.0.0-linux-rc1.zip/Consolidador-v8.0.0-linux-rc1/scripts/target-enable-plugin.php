<?php
// Habilita un módulo de actividad standard/core ya instalado en el destino.
declare(strict_types=1);

define('CLI_SCRIPT', true);
require('/var/www/html/config.php');
require_once($CFG->libdir . '/clilib.php');

[$options, $unrecognized] = cli_get_params(
    ['component' => null, 'help' => false],
    ['h' => 'help']
);
if ($options['help']) {
    cli_writeln("Uso: php target-enable-plugin.php --component=mod_x\n");
    exit(0);
}
if ($unrecognized) {
    cli_error('Opciones no reconocidas: ' . implode(', ', $unrecognized));
}

try {
    $component = core_text::strtolower(trim((string)$options['component']));
    if (!preg_match('/^mod_[a-z][a-z0-9_]*$/', $component)) {
        throw new RuntimeException('Solo se habilitan módulos mod_* requeridos por cursos.');
    }
    [, $name] = explode('_', $component, 2);
    $manager = core_plugin_manager::instance();
    $plugins = $manager->get_plugins_of_type('mod');
    if (!isset($plugins[$name])) {
        throw new RuntimeException("Módulo no instalado: $component");
    }
    $plugin = $plugins[$name];
    if (method_exists($plugin, 'is_standard') && !$plugin->is_standard()) {
        throw new RuntimeException(
            "El módulo adicional $component debe resolverse mediante el catálogo/pin.");
    }
    $class = core_plugin_manager::resolve_plugininfo_class('mod');
    if (!is_callable([$class, 'enable_plugin'])) {
        throw new RuntimeException("Moodle no expone enable_plugin para $component");
    }
    $before = (int)$DB->get_field('modules', 'visible', ['name' => $name], MUST_EXIST);
    $changed = $class::enable_plugin($name, 1);
    purge_all_caches();
    $after = (int)$DB->get_field('modules', 'visible', ['name' => $name], MUST_EXIST);
    if ($after !== 1) {
        throw new RuntimeException("No fue posible habilitar $component");
    }
    cli_writeln(
        'TARGET_PLUGIN_ENABLED component=' . $component .
        ' before=' . $before .
        ' after=' . $after .
        ' changed=' . ($changed ? '1' : '0')
    );
} catch (Throwable $error) {
    cli_error('TARGET_PLUGIN_ENABLE_ERROR ' . $error->getMessage());
}
