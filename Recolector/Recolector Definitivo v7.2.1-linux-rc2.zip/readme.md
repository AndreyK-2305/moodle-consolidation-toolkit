# Recolector Moodle

Versión `7.2.1-linux-rc2` del componente que extrae cada Moodle de origen y
genera un ZIP portable para el Consolidador. La recolección no modifica
usuarios, cursos, matrículas ni configuración del sitio.

La RC2 conserva los valores decimales terminados en `.0` al serializar los
inventarios. Esto mantiene estable `source_state_sha256` entre la exportación
y la validación exhaustiva de cursos con calificaciones enteras representadas
como valores decimales.

El validador RC2 también normaliza de forma estricta los campos `grade` y
`sumgrades`, por lo que puede volver a auditar un paquete creado por la RC1 que
solo hubiera fallado por esta diferencia de serialización.

## Requisitos

- Linux con Bash y PHP CLI.
- Extensión PHP `zip`/`ZipArchive`.
- Acceso de lectura al `config.php` y a los datos de Moodle.
- `systemd-run` y `sudo` solo para el modo en segundo plano.

## Uso

Con la ruta predeterminada `/var/www/html/config.php`:

```bash
chmod +x EXPORTAR-ORIGEN.sh
./EXPORTAR-ORIGEN.sh campus-norte.zip
```

Con una ruta distinta:

```bash
./EXPORTAR-ORIGEN.sh campus-norte.zip /srv/moodle/config.php
```

El nombre sin `.zip` se usa como identificador, nombre del origen, salida y
espacio de checkpoints. Puede contener letras minúsculas, números, guion y
guion bajo, y debe iniciar con una letra.

La salida predeterminada es:

```text
salidas/campus-norte.zip
salidas/campus-norte.zip.sha256
```

Para cambiar el directorio sin añadir otro parámetro:

```bash
MOODLE_COLLECTOR_OUTPUT_DIR=/mnt/exportaciones \
  ./EXPORTAR-ORIGEN.sh campus-norte.zip
```

## Segundo plano

```bash
sudo ./EXPORTAR-ORIGEN.sh --background campus-norte.zip
```

Con `config.php` explícito:

```bash
sudo ./EXPORTAR-ORIGEN.sh --background \
  campus-norte.zip /srv/moodle/config.php
```

Consulta de ejemplo:

```bash
sudo systemctl status moodle-recolector-campus-norte.service
tail -f salidas/logs/campus-norte-*.log
cat salidas/campus-norte.status.json
```

## Contenido del paquete

```text
cursos/*.mbz
inventarios/*.json
identidades.json
inventario-origen.json
plugins.json
checkpoints/*.json
manifest.json
checksums.sha256
```

Cada curso se respalda con la API oficial de Moodle. El proceso es secuencial,
con checkpoints reanudables, hashes SHA-256 y sin recomprimir los `.mbz` dentro
del ZIP exterior.

## Identidad OAuth

El esquema `identidades.json` 1.2 separa el identificador operativo que Moodle
guarda en `auth_oauth2_linked_login.username` del `sub` de Google:

- `google_sub` solo contiene un subject con evidencia verificable;
- `oauth_linked_username` conserva el identificador real del vínculo;
- `oauth_identifier_kind` lo clasifica como `sub`, `email`, `opaque` o
  `unknown`;
- `oauth_issuers` conserva los mapeos de campos de cada emisor.

Un correo utilizado para iniciar sesión no se etiqueta como `google_sub`.

## Auditoría exhaustiva opcional

La recolección normal sella el paquete sin volver a calcular todos los hashes.
Para realizar la auditoría costosa bajo demanda:

```bash
chmod +x VALIDAR-PAQUETE.sh
./VALIDAR-PAQUETE.sh /ruta/campus-norte.zip
```

En segundo plano:

```bash
sudo ./VALIDAR-PAQUETE.sh --background /ruta/campus-norte.zip
```

La auditoría recalcula el hash del ZIP, verifica todos los archivos internos y
cruza manifiesto, inventarios, checkpoints y backups. El archivo `.zip.sha256`
es opcional para esta auditoría: si falta, se registra una advertencia y la
validación interna continúa.

## SMTP opcional

Copie `smtp-config.example.json` como `smtp-config.json`, complete los datos y
proteja el archivo:

```bash
chmod 600 smtp-config.json
```

Los correos informan éxito o error, pero nunca sustituyen el log ni el archivo
de estado y no bloquean el resultado de la recolección.

## Docker

Si Moodle se ejecuta en Docker, el Recolector debe correr dentro del contenedor
de Moodle o en otro entorno con PHP CLI, acceso a la instalación y lectura del
`config.php`.
